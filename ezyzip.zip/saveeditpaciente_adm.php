<?php

//include('inserirpaciente_edit.php');

require_once('conecta.php');
    if(isset($_POST['submit'])) {
        
    $id=$_POST['id'];
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $idade = $_POST['idade'];
    $telefone = $_POST['telefone'];
    $genero = $_POST['genero'];
    $nome_acompanhante = $_POST['nome_acompanhante'];
    $idade_acompanhante = $_POST['idade_acompanhante'];
    $ocorrencia = $_POST['ocorrencia'];
    

    $sql = $pdo->prepare("UPDATE paciente SET nome=:nome, cpf=:cpf, idade=:idade, telefone=:telefone, sexo=:genero, nome_acompanhante=:nome_acompanhante, idade_acompanhante=:idade_acompanhante WHERE id_paciente=:id_paciente");
    $sql2 = $pdo->prepare("UPDATE ocorrencia SET ocorrencia=:ocorrencia WHERE id_paciente=:id_paciente");

    $sql2->bindParam(":ocorrencia", $ocorrencia);
    $sql->bindParam(":nome", $nome);
    $sql->bindParam(":cpf", $cpf);
    $sql->bindParam(":idade", $idade);
    $sql->bindParam(":telefone", $telefone);
    $sql->bindParam(":genero", $genero);
    $sql->bindParam(":nome_acompanhante", $nome_acompanhante);
    $sql->bindParam(":idade_acompanhante", $idade_acompanhante);
    $sql->bindParam(":id_paciente", $id);
    $sql2->bindParam(":id_paciente", $id);
    

    $sql->execute();
    $sql2->execute();

    header("Location: dashbomb.php");
    }


    ?>
