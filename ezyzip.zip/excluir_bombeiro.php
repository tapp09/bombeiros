<?php
    include("conecta.php");
    $ex_user = $_GET["id"];
        
        $comando = $pdo->prepare("DELETE FROM cadastro WHERE id=?");
        $comando->execute([$ex_user]);

    header("Location: dashadm.php");
?>