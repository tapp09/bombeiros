<?php
    include("conecta.php");
    require_once("inserir.php");


    if (isset($_POST['Proximo'])) {

        $hospital  = $_POST["hospital"];
        $local  = $_POST["local"];
        $data     = $_POST["data"];
        $id_paciente = idpaciente();


        $comando = $pdo->prepare("INSERT INTO hospital(hospital, local, data, id_paciente) VALUES('$hospital', '$local', '$data', '$id_paciente')");
        $resultado = $comando->execute();
    }
    

    // Para voltar no formulário:
?>