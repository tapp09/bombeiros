<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/bombeiros/css/problemas.css">
<title>Problemas Suspeitos</title>
</head>
<body>
<header>
   <img src="/bombeiros/images/logo_medicina.png" alt="Logo dos Bombeiros Voluntários">
   <h1>Bombeiros Voluntários</h1>
</header>
<div class="container">
    <div class="scrollable-content">
        <h2>PROBLEMAS SUSPEITOS</h2>
        <div class="separator"></div>
        <div class="checkbox-list">
            <label><input type="checkbox"><span class="problemas">PSIQUIÁTRICOS</span></label>
            <label><input type="checkbox"><span class="problemas">RESPIRATORIOS</span></label>
            <div class="suboptions respiratorios">
                <label><input type="checkbox"><span class="problemas">DPOC</span></label>
                <label><input type="checkbox"><span class="problemas">INALAÇÃO DE FUMAÇA</span></label>
            </div>
            <label><input type="checkbox"><span class="problemas">DIABETES</span></label>
            <div class="suboptions diabetes">
                <label><input type="checkbox"><span class="problemas">HIPERGLICEMIA</span></label>
                <label><input type="checkbox"><span class="problemas">HIPOGLICEMIA</span></label>
            </div>
            <label><input type="checkbox"><span class="problemas">OBSTÉTRICO</span></label>
            <div class="suboptions obstetricos">
                <label><input type="checkbox"><span class="problemas">PARTO EMERGENCIAL</span></label>
                <label><input type="checkbox"><span class="problemas">GESTANTE</span></label>
                <label><input type="checkbox"><span class="problemas">HEMOR. EXCESSIVA</span></label>
            </div>
            <label><input type="checkbox"><span class="problemas">TRANSPORTE</span></label>
            <div class="suboptions transporte">
                <label><input type="checkbox"><span class="problemas">AÉREO</span></label>
                <label><input type="checkbox"><span class="problemas">CLÍNICO</span></label>
                <label><input type="checkbox"><span class="problemas">EMERGENCIAL</span></label>
                <label><input type="checkbox"><span class="problemas">PÓS-TRAUMA</span></label>
                <label><input type="checkbox"><span class="problemas">SEM REMOÇÃO</span></label>
                <label><input type="checkbox"><span class="problemas">OUTRO</span></label>
                <input type="text" id="outrot" name="outrot">
            </div>
            <BR>
            <label><input type="checkbox" id="outrosCheckbox"><span class="problemas">OUTROS PROBLEMAS</span></label>
            <input type="text" id="outrosInput" class="outros-input text-input" placeholder="Informe outros problemas" disabled>
        </div>
    </div>
</div>
<footer>
    <a href="ocorrencias.php" class="botao">Voltar</a>
    <a href="sintomas.html" class="botao">Próximo</a>
</footer>
<script>
    const outrosCheckbox = document.getElementById('outrosCheckbox');
    const outrosInput = document.getElementById('outrosInput');

    outrosCheckbox.addEventListener('change', function() {
        outrosInput.disabled = !this.checked;
    });
</script>
</body>
</html>
