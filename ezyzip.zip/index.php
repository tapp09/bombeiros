<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="home.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NOAR</title>
</head>
<body>
    <div class="back">
        <div class="somb-back">
            <div class="nav">
                <div class="nav-logo">
                    <h1>NOAR</h1>
                </div>
                <div class="nav-links">
                    <ol>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="registro.php">Cadastro</a></li>
                    </ol>
                </div>
            </div>
            <div class="msg">
                
            </div>
        </div>
    </div>
</body>
</html>