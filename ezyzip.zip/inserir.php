<?php
    include("conecta.php");



    $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);


    if (isset($_POST['enviar'])) {


        $nome  = $_POST["nome"];
        $cpf      = $_POST["cpf"];
        $idade     = $_POST["idade"];
        $telefone     = $_POST["telefone"];
        $genero     = $_POST["genero"];
        $nomeacompanhante  = $_POST["nome-acompanhante"];
        $idadeacompanhante     = $_POST["idade-acompanhante"];

        $comando = $pdo->prepare("INSERT INTO paciente (nome, cpf, idade, telefone, sexo, nome_acompanhante, idade_acompanhante, id_paciente)  VALUES('$nome','$cpf','$idade', '$telefone','$genero', '$nomeacompanhante','$idadeacompanhante', null)" );
        $resultado = $comando->execute();

        $id_paciente = $pdo->lastInsertId();

        $hospital  = $_POST["hospital"];
        $local  = $_POST["local"];
        $data     = $_POST["data"];


        $comando = $pdo->prepare("INSERT INTO hospital(hospital, local, data, idp) VALUES('$hospital', '$local', '$data', '$id_paciente')");
        $resultado = $comando->execute();


        $ocorrencia  = $_POST["ocorrencia"];
        $problema  = $_POST["problemas"];
        $subproblema     = $_POST["subproblema"];


        $comando = $pdo->prepare("INSERT INTO ocorrencia(id, ocorrencia, problema, subproblema, id_paciente) VALUES(null, '$ocorrencia', '$problema', '$subproblema', '$id_paciente')");
        $resultado = $comando->execute();

        $sinais  = $_POST["sinais"];
        $subsinais  = $_POST["subsinais"];


        $comando = $pdo->prepare("INSERT INTO sintomas(id, sinais, sintomas, id_paciente) VALUES(null, '$sinais', '$subsinais', '$id_paciente')");
        $resultado = $comando->execute();

        $idade  = $_POST["ava_idade"]; 
        $ocular  = $_POST["ocular"];
        $verbal  = $_POST["verbal"];
        $motora  = $_POST["motora"];
        

        $comando = $pdo->prepare("INSERT INTO avaliacao_paciente(id, idade, ocular, verbal, motora, id_paciente) VALUES(null, '$idade', '$ocular', '$verbal', '$motora', '$id_paciente')");
        $resultado = $comando->execute();


        $pressao  = $_POST["pa"]; 
        $pulso  = $_POST["pulso"];
        $respiracao  = $_POST["resp"];
        $saturacao  = $_POST["sat"];
        $hgt  = $_POST["hgt"];
        $condicao  = $_POST["condicao"];
        $temperatura = $_POST["temp"];
        $perfusao = $_POST["perfusao"];
        

        $comando = $pdo->prepare("INSERT INTO sinais_pg(id, pressao_arterial, pulso, respiracao, saturacao, hgt, condicao, temperatura, perfusao, id_paciente) VALUES(null, '$pressao', '$pulso', '$respiracao', '$saturacao', '$hgt', '$condicao', '$temperatura', '$perfusao', '$id_paciente')");
        $resultado = $comando->execute();

        $pressao  = $_POST["pa"]; 
        $pulso  = $_POST["pulso"];
        $respiracao  = $_POST["resp"];
        $saturacao  = $_POST["sat"];
        $hgt  = $_POST["hgt"];
        $condicao  = $_POST["condicao"];
        $temperatura = $_POST["temp"];
        $perfusao = $_POST["perfusao"];
        

        $comando = $pdo->prepare("INSERT INTO sinais_pg(id, pressao_arterial, pulso, respiracao, saturacao, hgt, condicao, temperatura, perfusao, id_paciente) VALUES(null, '$pressao', '$pulso', '$respiracao', '$saturacao', '$hgt', '$condicao', '$temperatura', '$perfusao', '$id_paciente')");
        $resultado = $comando->execute();


        $frente_corpo  = $_POST["frente_corpo"]; 
        $costas_corpo  = $_POST["costas_corpo"];

        $comando = $pdo->prepare("INSERT INTO parte_corpo(id, frente, costas, id_paciente) VALUES(null, '$frente_corpo', '$costas_corpo', '$id_paciente')");
        $resultado = $comando->execute();


            $cabeca_frente  = $_POST["cabeca_frente"]; 
            $peito_frente  = $_POST["peito_frente"];
            $braco1_frente  = $_POST["braco1_frente"];
            $braco2_frente = $_POST["braco2_frente"];
            $abdomen_frente  = $_POST["abdomen_frente"];
            $genitalia_frente  = $_POST["genitalia_frente"];
            $perna1_frente  = $_POST["perna1_frente"];
            $perna2_frente  = $_POST["perna2_frente"];

        $comando = $pdo->prepare("INSERT INTO corpo_frente(id, cabeca, peito, braco_direito, braco_esquerdo, abdomen, genitalia, perna_direita, perna_esquerda, id_paciente) VALUES(null, '$cabeca_frente', '$peito_frente', '$braco1_frente', '$braco2_frente', '$abdomen_frente', '$genitalia_frente', '$perna1_frente', '$perna2_frente', '$id_paciente')");
        $resultado = $comando->execute();

            $cabeca  = $_POST["cabeca"]; 
            $costas  = $_POST["costas"];
            $braco1  = $_POST["braco1"];
            $braco2 = $_POST["braco2"];
            $bunda  = $_POST["bunda"];
            $perna1  = $_POST["perna1"];
            $perna2  = $_POST["perna2"];

        $comando = $pdo->prepare("INSERT INTO corpo_costas(id, cabeca, costas, braco_direito, braco_esquerdo, bunda, perna_direita, perna_esquerda, id_paciente) VALUES(null, '$cabeca', '$costas', '$braco1', '$braco2', '$bunda', '$perna1', '$perna2', '$id_paciente')");
        $resultado = $comando->execute();

              $prt_corpo  = $_POST["prt_corpo"];

                $comando = $pdo->prepare("INSERT INTO traumas(id, trauma, id_paciente) VALUES(null, '$prt_corpo', '$id_paciente')");
                $resultado = $comando->execute();
  


                $cabeca_q  = $_POST["cabeca_q"]; 
                $pescoco_q  = $_POST["pescoco_q"];
                $t_ant_q  = $_POST["t_ant_q"];
                $t_pos_q = $_POST["t_pos_q"];
                $genitais_q  = $_POST["genitais_q"];
                $m_i_d_q  = $_POST["m_i_d_q"];
                $m_i_e_q  = $_POST["m_i_e_q"];
                $m_s_d_q  = $_POST["m_s_d_q"];
                $m_s_e_q  = $_POST["m_s_e_q"];

                $cabeca_qdois  = $_POST["cabeca_qdois"]; 
                $pescoco_qdois  = $_POST["pescoco_qdois"];
                $t_ant_qdois  = $_POST["t_ant_qdois"];
                $t_pos_qdois = $_POST["t_pos_qdois"];
                $genitais_qdois  = $_POST["genitais_qdois"];
                $m_i_d_qdois  = $_POST["m_i_d_qdois"];
                $m_i_e_qdois  = $_POST["m_i_e_qdois"];
                $m_s_d_qdois  = $_POST["m_s_d_qdois"];
                $m_s_e_qdois  = $_POST["m_s_e_qdois"];

                $cabeca_qtres  = $_POST["cabeca_qtres"]; 
                $pescoco_qtres  = $_POST["pescoco_qtres"];
                $t_ant_qtres  = $_POST["t_ant_qtres"];
                $t_pos_qtres = $_POST["t_pos_qtres"];
                $genitais_qtres  = $_POST["genitais_qtres"];
                $m_i_d_qtres  = $_POST["m_i_d_qtres"];
                $m_i_e_qtres  = $_POST["m_i_e_qtres"];
                $m_s_d_qtres  = $_POST["m_s_d_qtres"];
                $m_s_e_qtres  = $_POST["m_s_e_qtres"];


              if (isset($cabeca_q) || isset($pescoco_q)|| isset($t_ant_q) || isset($t_pos_q) || isset($genitais_q) || isset($m_i_d_q) || isset($m_i_e_q) || isset($m_s_d_q) || isset($m_s_e_q) || isset($cabeca_qdois) || isset($pescoco_qdois)|| isset($t_ant_qdois) || isset($t_pos_qdois) || isset($genitais_qdois) || isset($m_i_d_qdois) || isset($m_i_e_qdois) || isset($m_s_d_qdois) || isset($m_s_e_qdois) || isset($cabeca_qtres) || isset($pescoco_qtres)|| isset($t_ant_qtres) || isset($t_pos_qtres) || isset($genitais_qtres) || isset($m_i_d_qtres) || isset($m_i_e_qtres) || isset($m_s_d_qtres) || isset($m_s_e_qtres)) {

    
            $comando = $pdo->prepare("INSERT INTO umgrau(id, cabeca, pescoco, t_ant, t_pos, genitais, m_i_d, m_i_e, m_s_d, m_s_e, id_paciente) VALUES(null, '$cabeca_q', '$pescoco_q', '$t_ant_q', '$t_pos_q', '$genitais_q', '$m_i_d_q', '$m_i_e_q', '$m_s_d_q', '$m_s_e_q', '$id_paciente')");
            $resultado = $comando->execute();

    
                $comando = $pdo->prepare("INSERT INTO doisgrau(id, cabeca, pescoco, t_ant, t_pos, genitais, m_i_d, m_i_e, m_s_d, m_s_e, id_paciente) VALUES(null, '$cabeca_qdois', '$pescoco_qdois', '$t_ant_qdois', '$t_pos_qdois', '$genitais_qdois', '$m_i_d_qdois', '$m_i_e_qdois', '$m_s_d_qdois', '$m_s_e_qdois', '$id_paciente')");
            $resultado = $comando->execute();
  
  
  
            $comando = $pdo->prepare("INSERT INTO tresgrau(id, cabeca, pescoco, t_ant, t_pos, genitais, m_i_d, m_i_e, m_s_d, m_s_e, id_paciente) VALUES(null, '$cabeca_qtres', '$pescoco_qtres', '$t_ant_qtres', '$t_pos_qtres', '$genitais_qtres', '$m_i_d_qtres', '$m_i_e_qtres', '$m_s_d_qtres', '$m_s_e_qtres', '$id_paciente')");
              $resultado = $comando->execute();

              }



              $conducao  = $_POST["conducao"]; 
              $decisao  = $_POST["decisao"];

          $comando = $pdo->prepare("INSERT INTO transporte(id, conducao, decisao, id_paciente) VALUES(null, '$conducao', '$decisao', '$id_paciente')");
          $resultado = $comando->execute();

          $vitima  = $_POST["vitima"]; 

          $comando = $pdo->prepare("INSERT INTO vitima(id, vitima, id_paciente) VALUES(null, '$vitima', '$id_paciente')");
          $resultado = $comando->execute();



          $contem  = $_POST["objeto"]; 
            $especificacao  = $_POST["objetostxt"];

          $comando = $pdo->prepare("INSERT INTO objetos(id, contem, especificacao, id_paciente) VALUES(null, '$contem', '$especificacao', '$id_paciente')");
          $resultado = $comando->execute();



        $m  = $_POST["medico"]; 
        $s1  = $_POST["s1"];
        $s2  = $_POST["s2"];
        $s3  = $_POST["s3"];
        $demandante  = $_POST["demandante"];
        $equipe  = $_POST["equipe"];

          $comando = $pdo->prepare("INSERT INTO equipe(id, m, sum, sdois, stres, demandante, equipe, id_paciente) VALUES(null, '$m', '$s1', '$s2', '$s3', '$demandante', '$equipe', '$id_paciente')");
          $resultado = $comando->execute();








          if (
            isset($aspiracao) || isset($avaliacao_inicial) || isset($avaliacao_dirigida) || isset($avaliacao_continuada) || isset($chave_de_rautek) || isset($canula_de_guedel) ||
            isset($desobstrucao_de_va) || isset($emprego_do_dea) || isset($gerenciamento_de_riscos) || isset($limpeza_de_ferimento) || isset($curativos) || isset($compressivo) ||
            isset($encravamento) || isset($ocular) || isset($queimadura) || isset($simples) || isset($tres_pontas) || isset($imobilizacoes) || isset($membr_infd) || isset($membr_infesq) ||
            isset($membr_supdir) || isset($membr_supesq) || isset($quadril) || isset($cervical) || isset($maca_sobre_rodas) || isset($maca_rigida) || isset($ponte) || isset($retirado_capacete) ||
            isset($rcp) || isset($rolamento_90) || isset($rolamento_180) || isset($tomada_decisao) || isset($tratado_choque) || isset($uso_de_canula) || isset($uso_colar) ||
            isset($uso_ked) || isset($uso_ttf) || isset($ventilacao_suporte) || isset($oxigenioterapia) || isset($celesc) || isset($def_civil) || isset($igp_po) || isset($policia_civil) ||
            isset($policia_militar) || isset($pre) || isset($prf) || isset($cit) || isset($samu_usa) || isset($samu_usb) || isset($tam) || isset($olpm) || isset($rlpm) || isset($auxiliar) ||
            isset($reanimador)
        ) {
            $aspiracao = $_POST["aspiracao"];
            $avaliacao_inicial = $_POST["avaliacao_inicial"];
            $avaliacao_dirigida = $_POST["avaliacao_dirigida"];
            $avaliacao_continuada = $_POST["avaliacao_continuada"];
            $chave_de_rautek = $_POST["chave_de_rautek"];
            $canula_de_guedel = $_POST["canula_de_guedel"];
            $desobstrucao_de_va = $_POST["desobstrucao_de_va"];
            $emprego_do_dea = $_POST["emprego_do_dea"];
            $gerenciamento_de_riscos = $_POST["gerenciamento_de_riscos"];
            $limpeza_de_ferimento = $_POST["limpeza_de_ferimento"];
            $curativos = $_POST["curativos"];
            $compressivo = $_POST["compressivo"];
            $encravamento = $_POST["encravamento"];
            $ocular = $_POST["ocular"];
            $queimadura = $_POST["queimadura"];
            $simples = $_POST["simples"];
            $tres_pontas = $_POST["3_pontas"];
            $imobilizacoes = $_POST["imobilizacoes"];
            $membr_infd = $_POST["membr_infd"];
            $membr_infesq = $_POST["membr_infesq"];
            $membr_supdir = $_POST["membr_supdir"];
            $membr_supesq = $_POST["membr_supesq"];
            $quadril = $_POST["quadril"];
            $cervical = $_POST["cervical"];
            $maca_sobre_rodas = $_POST["maca_sobre_rodas"];
            $maca_rigida = $_POST["maca_rigida"];
            $ponte = $_POST["ponte"];
            $retirado_capacete = $_POST["retirado_capacete"];
            $rcp = $_POST["rcp"];
            $rolamento_90 = $_POST["rolamento_90"];
            $rolamento_180 = $_POST["rolamento_180"];
            $tomada_decisao = $_POST["tomada_decisao"];
            $tratado_choque = $_POST["tratado_choque"];
            $uso_de_canula = $_POST["uso_de_canula"];
            $uso_colar = $_POST["uso_colar"];

            $uso_ked = $_POST["uso_ked"];
            $uso_ttf = $_POST["uso_ttf"];
            $ventilacao_suporte = $_POST["ventilacao_suporte"];
            $oxigenioterapia = $_POST["oxigenioterapia"];

            $celesc = $_POST["celesc"];
            $def_civil = $_POST["def_civil"];
            $igp_po = $_POST["igp_po"];
            $policia_civil = $_POST["policia_civil"];
            $policia_militar = $_POST["policia_militar"];
            $pre = $_POST["pre"];
            $prf = $_POST["prf"];
            $cit = $_POST["cit"];
            $samu_usa = $_POST["samu_usa"];
            $samu_usb = $_POST["samu_usb"];

            $tam = $_POST["tam"];
            $olpm = $_POST["olpm"];
            $rlpm = $_POST["rlpm"];
            $auxiliar = $_POST["auxiliar"];
            $reanimador = $_POST["reanimador"];


            $comando = $pdo->prepare("INSERT INTO procedimentos(id, aspiracao, avaliacao_inicial, avaliacao_dirigida, avaliacao_continuada, chave_de_rautek, canula_de_guedel, desobstrucao_de_va, emprego_do_dea, gerenciamento_de_riscos, limpeza_de_ferimento, curativos, compressivo, encravamento, ocular, queimadura, simples, tres_pontas, imobilizacoes, membr_infd, membr_infesq, membr_supdir, membr_supesq, quadril, cervical, maca_sobre_rodas, maca_rigida, ponte, retirado_capacete, rcp, rolamento_90, rolamento_180, tomada_decisao, tratado_choque, uso_de_canula, uso_colar, tam, uso_ked, uso_ttf, ventilacao_suporte, oxigenioterapia, olpm, reanimador, rlpm, auxiliar, celesc, def_civil, igp_po, policia_civil, policia_militar, pre, prf, cit, samu_usa, samu_usb, id_paciente) VALUES(null, '$aspiracao', '$avaliacao_inicial', '$avaliacao_dirigida', '$avaliacao_continuada', '$chave_de_rautek', '$canula_de_guedel', '$desobstrucao_de_va', '$emprego_do_dea', '$gerenciamento_de_riscos', '$limpeza_de_ferimento', '$curativos', '$compressivo', '$encravamento', '$ocular', '$queimadura', '$simples', '$tres_pontas', '$imobilizacoes', '$membr_infd', '$membr_infesq', '$membr_supdir', '$membr_supesq', '$quadril', '$cervical', '$maca_sobre_rodas', '$maca_rigida', '$ponte', '$retirado_capacete', '$rcp', '$rolamento_90', '$rolamento_180', '$tomada_decisao', '$tratado_choque', '$uso_de_canula', '$uso_colar', '$tam', '$uso_ked', '$uso_ttf', '$ventilacao_suporte', '$oxigenioterapia', '$olpm', '$reanimador', '$rlpm', '$auxiliar', '$celesc', '$def_civil', '$igp_po', '$policia_civil', '$policia_militar', '$pre', '$prf', '$cit', '$samu_usa', '$samu_usb', '$id_paciente')");
          $resultado = $comando->execute();

        }





            $atadura = $_POST["atadura"];
            $qtd_atadura = $_POST["qtd_atadura"];
            $tip_atadura = $_POST["tip_atadura"];
            $cateter = $_POST["cateter"];
            $qtd_cateter = $_POST["qtd_cateter"];
            $compressa = $_POST["compressa"];
            $qtd_compressa = $_POST["qtd_compressa"];
            $kits = $_POST["kits"];
            $qtd_kits = $_POST["qtd_kits"];
            $tip_kits = $_POST["tip_kits"];
            $luvas = $_POST["luvas"];
            $qtd_luvas = $_POST["qtd_luvas"];
            $mascara = $_POST["mascara"];
            $qtd_mascara = $_POST["qtd_mascara"];
            $manta = $_POST["manta"];
            $qtd_manta = $_POST["qtd_manta"];
            $pas = $_POST["pas"];
            $qtd_pas = $_POST["qtd_pas"];
            $soro = $_POST["soro"];
            $qtd_soro = $_POST["qtd_soro"];
            $tala = $_POST["tala"];
            $qtd_tala = $_POST["qtd_tala"];
            $tip_tala = $_POST["tip_tala"];
            $outro_mat = $_POST["outro_mat"];


        if ( isset($atadura) || isset($qtd_atadura) || isset($tip_atadura) || isset($cateter) || isset($qtd_cateter) || isset($compressa) || isset($qtd_compressa) || isset($kits) || isset($qtd_kits) || isset($tip_kits) || isset($luvas) || isset($qtd_luvas) || isset($mascara) || isset($qtd_mascara) || isset($manta) || isset($qtd_manta) || isset($pas) || isset($qtd_pas) || isset($soro) || isset($qtd_soro) || isset($tala) || isset($qtd_tala) || isset($tip_tala) || isset($outro_mat)) 
        {


            $comando = $pdo->prepare("INSERT INTO mat_desc(id, atadura, tip_atadura, qtd_atadura, cateter, qtd_cateter, compressa, qtd_compressa, kits, tip_kits, qtd_kits, luvas, qtd_luvas, mascara, qtd_mascara, manta, qtd_manta, pas, qtd_pas, soro, qtd_soro, talas, tip_talas, qtd_talas, outro, id_paciente) VALUES(null, '$atadura', '$tip_atadura', '$qtd_atadura', '$cateter', '$qtd_cateter', '$compressa', '$qtd_compressa', '$kits', '$tip_kits', '$qtd_kits', '$luvas', '$qtd_luvas', '$mascara', '$qtd_mascara', '$manta', '$qtd_manta', '$pas', '$qtd_pas', '$soro', '$qtd_soro', '$talas', '$tip_talas', '$qtd_talas', '$outro', '$id_paciente')");
            $resultado = $comando->execute();

        }



        $base = $_POST["base"];
        $qtd_base = $_POST["qtd_base"];
        $colar = $_POST["colar"];
        $qtd_colar = $_POST["qtd_colar"];
        $tip_colar = $_POST["tip_colar"];
        $coxin = $_POST["coxin"];
        $qtd_coxin = $_POST["qtd_coxin"];
        $ked = $_POST["ked"];
        $qtd_ked = $_POST["qtd_ked"];
        $tip_ked = $_POST["tip_ked"];
        $maca = $_POST["maca"];
        $t_t_f = $_POST["t_t_f"];
        $qtd_t_t_f = $_POST["qtd_t_t_f"];
        $tip_t_t_f = $_POST["tip_t_t_f"];
        $tirante_aranha = $_POST["tirante_aranha"];
        $qtd_tirante = $_POST["qtd_tirante"];
        $tirante_cabeca = $_POST["tirante_cabeca"];
        $qtd_tirantedois = $_POST["qtd_tirantedois"];
        $canula = $_POST["canula"];
        $qtd_canula = $_POST["qtd_canula"];

    

        $comando = $pdo->prepare("INSERT INTO mat_deixados(id, base, qtd_base, colar, qtd_colar, tip_colar, coxin, qtd_coxin, ked, qtd_ked, tip_ked, maca, t_t_f, qtd_t_t_f, tip_t_t_f, tirante_aranha, qtd_tirante, tirante_cabeca, qtd_tirantedois, canula, qtd_canula, id_paciente) VALUES(null, '$base', '$qtd_base', '$colar', '$qtd_colar', '$tip_colar', '$coxin', '$qtd_coxin', '$ked', '$qtd_ked', '$tip_ked', '$maca', '$t_t_f', '$qtd_t_t_f', '$tip_t_t_f', '$tirante_aranha', '$qtd_tirante', '$tirante_cabeca', '$qtd_tirantedois', '$canula', '$qtd_canula', '$id_paciente')");
        $resultado = $comando->execute();



        $ocorrido = $_POST["ocorrido"];
        $conf = $_POST["conf"];
        $tempo = $_POST["tempo"];
        $confdois = $_POST["confdois"];
        $problemas = $_POST["problemas"];
        $conftres = $_POST["conftres"];
        $medicacao = $_POST["medicacao"];
        $medicamentos = $_POST["medicamentos"];
        $confquatro = $_POST["confquatro"];
        $especificar = $_POST["especificar"];
        $confcinco = $_POST["confcinco"];
        $horaalimento = $_POST["horaalimento"];


        $comando = $pdo->prepare("INSERT INTO anamnese(id, ocorrido, conf, tempo, confdois, problemas, conftres, medicacao, medicamentos, confquatro, especificar, confcinco, horaalimento, id_paciente) VALUES(null, '$ocorrido', '$conf', '$tempo', '$confdois', '$problemas', '$conftres', '$medicacao', '$medicamentos', '$confquatro', '$especificar', '$confcinco', '$horaalimento', '$id_paciente')");
        $resultado = $comando->execute();




        $gestacao = $_POST["gestacao"];
        $prenatal = $_POST["prenatal"];
        $n_medico = $_POST["n_medico"];
        $complicacoes = $_POST["complicacoes"];
        $filho = $_POST["filho"];
        $qtd = $_POST["qtd"];
        $contracoes = $_POST["contracoes"];
        $duracao = $_POST["duracao"];
        $intervalo = $_POST["intervalo"];
        $pressao = $_POST["pressao"];
        $bolsa = $_POST["bolsa"];
        $inspecao = $_POST["inspecao"];
        $parto = $_POST["parto"];
        $nascimento = $_POST["nascimento"];
        $sexo = $_POST["sexo"];
        $nome_bebe = $_POST["nome_bebe"];

        $comando = $pdo->prepare("INSERT INTO anamnese_gest(id, gestacao, prenatal, n_medico, complicacoes, filho, qtd, contracoes, duracao, intervalo, pressao, bolsa, inspecao, parto, nascimento, sexo, nome_bebe, id_paciente) VALUES(null, '$gestacao', '$prenatal', '$n_medico', '$complicacoes', '$filho', '$qtd', '$contracoes', '$duracao', '$intervalo', '$pressao', '$bolsa', '$inspecao', '$parto',  '$nascimento', '$sexo', '$nome_bebe', '$id_paciente')");
        $resultado = $comando->execute();




            $disturbio  = $_POST["disturbio"]; 
            $capacete  = $_POST["capacete"];
            $cinto  = $_POST["cinto"]; 
            $parabrisas  = $_POST["parabrisas"];
            $caminhando  = $_POST["caminhando"]; 
            $painel  = $_POST["painel"];
            $volante  = $_POST["volante"]; 

          $comando = $pdo->prepare("INSERT INTO cinematica(id, disturbio, capacete, cinto, parabrisas, caminhando, painel, volante, id_paciente) VALUES(null, '$disturbio', '$capacete','$cinto', '$parabrisas','$caminhando', '$painel','$volante', '$id_paciente')");
          $resultado = $comando->execute();



            $observacao  = $_POST["observacao"]; 

          $comando = $pdo->prepare("INSERT INTO observacao(id, observacao, id_paciente) VALUES(null, '$observacao', '$id_paciente')");
          $resultado = $comando->execute();


          $nome  = $_POST["nome"]; 
          $fibra  = $_POST["fibra"]; 

          $comando = $pdo->prepare("INSERT INTO preenchimento(id, nome, fibra, id_paciente) VALUES(null, '$nome', '$fibra', '$id_paciente')");
          $resultado = $comando->execute();





 
        
        echo "<script> window.location.href='procedimentos.php';</script>";

        }




    
    

    // Para voltar no formulário:
?>