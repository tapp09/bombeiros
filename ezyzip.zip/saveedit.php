<?php

include('inserirlogin_edit.php');

require_once('conecta.php');
    if(isset($_POST['submit'])) {
        
    $nome  = $_POST['nome'];
    $cpf      = $_POST['cpf'];
    $telefone     = $_POST['telefone'];
    $email     = $_POST['email'];
    $senha      = md5($_POST['senha']);
    $id     = $_POST['id'];
    print_r($id);

    $sql = $pdo->prepare("update cadastro set nome=:nome, cpf=:cpf, telefone=:telefone, email=:email, senha=:senha WHERE id=:id");

    $sql->bindValue("nome", $nome);
    $sql->bindValue("cpf", $cpf);
    $sql->bindValue("telefone", $telefone);
    $sql->bindValue("email", $email);
    $sql->bindValue("senha", $senha);
    $sql->bindValue("id", $id);
    $sql->execute();

    header("Location: dashadm.php");
    }


    ?>
