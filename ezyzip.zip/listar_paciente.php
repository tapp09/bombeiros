<?php
        include_once("conecta.php");
        
        $comandop = $pdo->query("SELECT * FROM paciente;");
        
        
        if ($comandop->rowCount() >= 1) {
            $lista_pacientes = $comandop->fetchAll();
        } else {
            echo '';
        }
        
        unset($pdo);
        unset($comandop);
        
    ?>