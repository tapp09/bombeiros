<?php
        include_once("conecta.php");
        
        $comandop = $pdo->query("SELECT paciente.*,ocorrencia.ocorrencia FROM paciente INNER JOIN ocorrencia ON paciente.id_paciente=ocorrencia.id_paciente");
        
        
        if ($comandop->rowCount() >= 1) {
            $lista_pacientes = $comandop->fetchAll();
        } else {
            echo '';
        }
        
        unset($pdo);
        unset($comandop);
        
    ?>