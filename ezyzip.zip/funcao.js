let selectproblema = document.getElementById('problema');

selectproblema.onchange = function () {
    let selectsubproblema = document.getElementById('subproblema');
    let valor = selectproblema.value;

    fetch("select_subproblema.php?problema=" + valor)
        .then(response => {

            return response.text();

        })
        .then(content => {

            selectsubproblema.innerHTML = content;

        });

}



let selectsinais = document.getElementById('sinais');

selectsinais.onchange = function () {
    let selectsubsinais = document.getElementById('subsinais');
    let valor = selectsinais.value;

    fetch("select_subsinais.php?sinais=" + valor)
        .then(response => {

            return response.text();

        })
        .then(content => {

            selectsubsinais.innerHTML = content;

        });

}