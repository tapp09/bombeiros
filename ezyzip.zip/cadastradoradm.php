<?php
    include("conecta.php");

    $nome  = $_POST["nome"];
    $cpf      = $_POST["cpf"];
    $telefone     = $_POST["telefone"];
    $email     = $_POST["email"];
    $senha      = md5($_POST["senha"]);

    $comando = $pdo->prepare("INSERT INTO cadastro_adm VALUES('$nome','$cpf','$telefone', '$email','$senha', null)" );
    $resultado = $comando->execute();

    // Para voltar no formulário:
    header("Location: loginadm.php");
?>