<?php

include('inserirpaciente_edit.php');

require_once('conecta.php');
    if(isset($_POST['submit'])) {
        
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $idade = $_POST['idade'];
    $telefone = $_POST['telefone'];
    $genero = $_POST['genero'];
    $nome_acompanhante = $_POST['nome_acompanhante'];
    $idade_acompanhante = $_POST['idade_acompanhante'];
    $id = $_POST['id_paciente'];

    $sql = $pdo->prepare("update paciente set nome=:nome, cpf=:cpf, idade=:idade, telefone=:telefone, sexo=:genero, nome_acompanhante=:nome_acompanhante, idade_acompanhante=:idade_acompanhante WHERE id_paciente=:id_paciente");

    $sql->bindValue("nome", $nome);
    $sql->bindValue("cpf", $cpf);
    $sql->bindValue("idade", $idade);
    $sql->bindValue("telefone", $telefone);
    $sql->bindValue("genero", $genero);
    $sql->bindValue("nome_acompanhante", $nome_acompanhante);
    $sql->bindValue("idade_acompanhante", $idade_acompanhante);
    $sql->bindValue("id_paciente", $id);
    $sql->execute();

    header("Location: dashadm.php");
    }


    ?>
