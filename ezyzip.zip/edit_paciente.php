<!DOCTYPE html>
<html lang="en">
	

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="style.css">
	<title>
		Registro
	</title>
</head>
<?php
include('inserirpaciente_edit.php');
$id=$_GET['id'];
?>

<body>
	<div id="container" class="container">
		<!-- FORM SECTION -->
			<form action="saveeditpaciente.php" method="POST">
				<div class="form-group">
					<label for="nome">NOME PACIENTE</label>
					<input type="text" id="nome" name="nome" required>
				</div>
				<div class="form-group">
					<label for="cpf">CPF/RG</label>
					<input type="text" id="cpf" name="cpf" required>
				</div>
				<div class="form-group">
					<label for="idade">IDADE</label>
					<input type="text" id="idade" name="idade" required>
				</div>
				<div class="form-group">
					<label for="telefone">Telefone</label>
					<input type="text" id="telefone" name="telefone" required>
				</div>
				<div class="form-group checkbox-group">
					<label for="genero">SEXO</label>
					<input type="radio" name="genero" value="masculino"> M
					<input type="radio" name="genero" value="feminino"> F
					<div class="clear"></div>
				</div>
				<input type="hidden" name="id" value="<?=$id ?>">
				<div class="separator"></div>
				<div class="form-group">
					<label for="nome-acompanhante">NOME ACOMPANHANTE </label>
					<input type="text" id="nome_acompanhante" name="nome_acompanhante">
				</div>
				<div class="form-group">
					<label for="idade-acompanhante">IDADE </label>
					<input type="text" id="idade_acompanhante" name="idade_acompanhante">
				</div>
				<select name="ocorrencia" id="ocorrencia" required>
					<option value="CAUSADO POR ANIMAIS">CAUSADO POR ANIMAIS</option>
					<option value="COM MEIO DE TRANSPORTE">COM MEIO DE TRANSPORTE</option>
					<option value="DESMORONAMENTO / DESLIZAMENTO">DESMORONAMENTO / DESLIZAMENTO</option>
					<option value="EMERGÊNCIA MÉDICA">EMERGÊNCIA MÉDICA</option>
					<option value="QUEDA DE ALTURA 2M">QUEDA DE ALTURA 2M</option>
					<option value="TENTATIVA DE SUICÍDIO">TENTATIVA DE SUICÍDIO</option>
					<option value="QUEDA PRÓPRIA ALTURA">QUEDA PRÓPRIA ALTURA</option>
					<option value="AFOGAMENTO">AFOGAMENTO</option>
					<option value="AGRESSÃO">AGRESSÃO</option>
					<option value="ATROPELAMENTO">ATROPELAMENTO</option>
					<option value="DOMÉSTICO">DOMÉSTICO</option>
					<option value="ESPORTIVO">ESPORTIVO</option>
					<option value="QUEDA BICICLETA">QUEDA BICICLETA</option>
					<option value="QUEDA MOTO">QUEDA MOTO</option>
					<option value="QUEDA NÍVEL +2M">QUEDA NÍVEL +2M</option>
					<option value="TRABALHO">TRABALHO</option>
					<option value="TRANSFERÊNCIA">TRANSFERÊNCIA</option>
					<option value="CHOQUE ELÉTRICO">CHOQUE ELÉTRICO</option>
					<option value="DESABAMENTO">DESABAMENTO</option>
					<option value="NENHUMA DAS OPÇÕES">NENHUMA DAS OPÇÕES</option>
				</select>


				<input type="submit" name="submit" value="ENVIAR">
		</form>

		<!-- END FORM SECTION -->
		<!-- CONTENT SECTION -->
		<div class="row content-row">
			<!-- SIGN IN CONTENT -->
			<div class="col align-items-center flex-col">
			</div>
			<!-- END SIGN IN CONTENT -->
			<!-- SIGN UP CONTENT -->
			<div class="col align-items-center flex-col">
				<div class="img img-mx sign-up">
					<img src="bomblg.png" alt="welcome">
				</div>
				<div class="text sign-up">
					<h2>
						REGISTRO NOAR
					</h2>
					<p id="txt">
						A coragem é a força que nos impulsiona a enfrentar o desconhecido, a superar nossos medos e a persistir diante dos desafios. É o combustível da determinação que nos permite alcançar o impossível.
					</p>
				</div>
			</div>
			<!-- END SIGN UP CONTENT -->
		</div>
		<!-- END CONTENT SECTION -->
	</div>

	<script src="registro.js"></script>
</body>

</html>