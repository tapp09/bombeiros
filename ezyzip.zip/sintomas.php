<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/bombeiros/css/sintomas.css">
<title>Sinais e sintomas</title>

</head>
<body>
<header>
   <img src="/bombeiros/images/logo_medicina.png" alt="Logo dos Bombeiros Voluntários">
   <h1>Bombeiros Voluntários</h1>
</header>
<div class="container">
    <div class="scrollable-content">
        <h2>SINAIS E SINTOMAS</h2>
        <div class="separator"></div>
    <div class="checkbox-list">
        <label><input type="checkbox"><span class="sintomas">ABDOMEM SENSIVEL OU RÍGIDO</span></label>
        <label><input type="checkbox"><span class="sintomas">AFUNDAMENTO DE CRÂNIO</span></label>
        <label><input type="checkbox"><span class="sintomas">AGITAÇÃO</span></label>
        <label><input type="checkbox"><span class="sintomas">AMNÉSIA</span></label>
        <label><input type="checkbox"><span class="sintomas">ANGINA DE PEITO</span></label>
        <label><input type="checkbox"><span class="sintomas">APINÉIA</span></label>
        <label><input type="checkbox"><span class="sintomas">BRADICARDIA</span></label>
        <label><input type="checkbox"><span class="sintomas">BRADIPNÉIA</span></label>
        <label><input type="checkbox"><span class="sintomas">BRONCO ASPIRANDO</span></label>
        <label><input type="checkbox"><span class="sintomas">CEFALEIA</span></label>

        <label><input type="checkbox"><span class="sintomas">CIANOSE</span></label>
        <div class="suboptions cianose">
            <label><input type="checkbox"><span class="sintomas">LÁBIOS</span></label>
            <label><input type="checkbox"><span class="sintomas">EXTREMIDADE</span></label>
        </div>

        <label><input type="checkbox"><span class="sintomas">CONVULSÃO</span></label>
        <label><input type="checkbox"><span class="sintomas">DECORTICAÇÃO</span></label>
        <label><input type="checkbox"><span class="sintomas">DEFORMIDADE</span></label>
        <label><input type="checkbox"><span class="sintomas">DESCEREBRAÇÃO</span></label>
        <label><input type="checkbox"><span class="sintomas">DESMAIO</span></label>
        <label><input type="checkbox"><span class="sintomas">DESVIO DE TRAQUEIA</span></label>
        <label><input type="checkbox"><span class="sintomas">DISPNEIA</span></label>
        <label><input type="checkbox"><span class="sintomas">DOR LOCAL</span></label>

        <label><input type="checkbox"><span class="sintomas">EDEMA</span></label>
        <div class="suboptions edema">
            <label><input type="checkbox"><span class="sintomas">LOCALIZADO</span></label>
            <label><input type="checkbox"><span class="sintomas">GENERALIZADO</span></label>
        </div>

        <label><input type="checkbox"><span class="sintomas">ENFISEMA SUBCUTÁNEO</span></label>
        <label><input type="checkbox"><span class="sintomas">ÉSTASE DE JUGULAR</span></label>
        <label><input type="checkbox"><span class="sintomas">FACE PALIDA</span></label>
        <label><input type="checkbox"><span class="sintomas">HEMORRAGIA</span></label>
        <div class="suboptions hemorragia">
            <label><input type="checkbox"><span class="sintomas">INTERNA</span></label>
            <label><input type="checkbox"><span class="sintomas">EXTERNA</span></label>
        </div>

        <label><input type="checkbox"><span class="sintomas">HIPERTENSÃO</span></label>
        <label><input type="checkbox"><span class="sintomas">HIPOTENSÃO</span></label>
        <label><input type="checkbox"><span class="sintomas">NAUSEAS E VÓMITOS</span></label>
        <label><input type="checkbox"><span class="sintomas">NASORAGIA</span></label>
        <label><input type="checkbox"><span class="sintomas">OBITO</span></label>
        <label><input type="checkbox"><span class="sintomas">OTORREIA</span></label>
        <label><input type="checkbox"><span class="sintomas">OTORRAGIA</span></label>
        <label><input type="checkbox"><span class="sintomas">O.V.A.C.E</span></label>
        <label><input type="checkbox"><span class="sintomas">PARADA</span></label>
        <div class="suboptions parada">
            <label><input type="checkbox"><span class="sintomas">CARDÍACA</span></label>
            <label><input type="checkbox"><span class="sintomas">RESPIRATÓRIA</span></label>
        </div>

        <label><input type="checkbox"><span class="sintomas">PRIAPRISMO</span></label>
        <label><input type="checkbox"><span class="sintomas">PRURIDO NA PELE</span></label>
        <label><input type="checkbox"><span class="sintomas">PUPILAS</span></label>
        <div class="suboptions pupilas">
            <label><input type="checkbox"><span class="sintomas">ANISOCORIA</span></label>
            <label><input type="checkbox"><span class="sintomas">ISOCORIA</span></label>
            <label><input type="checkbox"><span class="sintomas">MIDRIASE</span></label>
            <label><input type="checkbox"><span class="sintomas">MIOSE</span></label>
            <label><input type="checkbox"><span class="sintomas">REAGENTE</span></label>
            <label><input type="checkbox"><span class="sintomas">NÃO REAGENTE</span></label>
        </div>

        <label><input type="checkbox"><span class="sintomas">SEDE</span></label>
        <label><input type="checkbox"><span class="sintomas">SINAL DE BATTLE</span></label>
        <label><input type="checkbox"><span class="sintomas">SUDORESE</span></label>
        <label><input type="checkbox"><span class="sintomas">TAQUIPNEIA</span></label>
        <label><input type="checkbox"><span class="sintomas">TAQUICARDIA</span></label>
        <label><input type="checkbox"><span class="sintomas">TONTURA</span></label>
        <label><input type="checkbox"><span class="sintomas">OUTRO</span></label>
        <input type="text" id="outrosinal" name="outrotsinal">
    </div>
    </div>
</div>
<footer>
    <a href="problemas.php" class="botao">Voltar</a>
    <a href="avaliacao.html" class="botao">Próximo</a>
</footer>
</body>
</html>
