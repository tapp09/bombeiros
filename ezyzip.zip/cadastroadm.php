<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="cadastradoradm.php" method="POST" >
							<input type="text" id="nome" name="nome" placeholder="Nome" require>
							<input type="number" id="cpf" name="cpf" placeholder="150.834.756-32" require>
							<input type="number" id="telefone" name="telefone" placeholder="47988435234" require>
							<input type="email" id="email" name="email" placeholder="Email" require>
							<input type="password" id="senha" name="senha" placeholder="Senha" require>
						<button>
							ENVIAR
						</button>
			
</form>
</body>
</html>