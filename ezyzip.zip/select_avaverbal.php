<?php

include('conecta.php');

$idade = $_GET['idava'];

$query = $pdo->PREPARE("SELECT id, nome
     FROM avaverbal
     WHERE idade_id=:idade_id
     ORDER BY nome ASC");

     $data = ['idade_id' => $idade];

     $query->execute($data);
    $registros = $query->fetchAll(PDO::FETCH_ASSOC);

    echo '<option value="">Selecione uma opção</option>';

    foreach($registros as $option) {
      ?>
        <option value="<?php echo $option['id']?>"><?php echo $option['nome']?></option>
        <?php
    }