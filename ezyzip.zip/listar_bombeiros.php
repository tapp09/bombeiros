<?php
        include_once("conecta.php");
        
        $comando = $pdo->query("SELECT * FROM cadastro;");
        
        
        if ($comando->rowCount() >= 1) {
            $lista_bombeiros = $comando->fetchAll();
        } else {
            echo '';
        }
        
        
        ?>