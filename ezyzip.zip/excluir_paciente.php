<?php
    include("conecta.php");
    $ex_user = $_GET["id_paciente"];
        
    $comando = $pdo->prepare("DELETE FROM bombeiro WHERE id_paciente=$ex_user AND id_paciente=$ex_user SET FOREIGN_KEY_CHECKS = 0;");
    $comando->execute();

    header("Location: dashadm.php");
?>