<?php
    include("conecta.php");
    $ex_user = $_GET["id_paciente"];
        
    $comando = $pdo->prepare("DELETE FROM anamnese WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM anamnese_gest WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM avaliacao_paciente WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM cinematica WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM corpo_costas WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM corpo_frente WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM doisgrau WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM equipe WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM hospital WHERE idp=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM mat_deixados WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM mat_desc WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM objetos WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM observacao WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM ocorrencia WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM procedimentos WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM parte_corpo WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM preenchimento WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM sinais_pg WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM sintomas WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM transporte WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM traumas WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM tresgrau WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM umgrau WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM vitima WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    $comando = $pdo->prepare("DELETE FROM paciente WHERE id_paciente=?");
    $comando->execute([$ex_user]);

    header("Location: dashadm.php");
?>