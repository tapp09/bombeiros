<?php
    include("conecta.php");



    if(isset($_GET['id'])){
        $id=($_GET['id']);

        try {
            $sql = $pdo->prepare("SELECT * FROM cadastro WHERE id=:id");
            $sql->bindValue("id", $id);
            $sql->execute();
            $resultado = $sql->fetch(PDO::FETCH_ASSOC);
            print_r($resultado);

            if($sql->rowCount()>0) {
                $nome = $resultado["nome"];
                $cpf = $resultado['cpf'];
                $telefone = $resultado['telefone'];
                $email = $resultado['email'];
                $senha = $resultado['senha'];
            }
        } catch (PDOException $erro) {
            echo "houve erro, usuario não cadastrado";
        }


    }
    


    // Para voltar no formulário:
?>