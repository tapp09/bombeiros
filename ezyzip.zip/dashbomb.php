<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="home.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NOAR</title>
</head>
<body>

<table border="1" class="tabela">
            <thead>
                <tr>
                    <th> Código </th>
                    <th> Nome </th>
                    <th> telefone </th>
                    <th> idade</th>
                    <th> cpf </th>
                    <th> Ocorrencia </th>
                    <th colspan="5"> Ações </th>
                </tr>
            </thead>
            <tbody>
            <?php
                            include_once("listar_paciente.php");
                            if(!empty($lista_pacientes)){
                                foreach($lista_pacientes as $linhap){
                                    echo ' <tr>
                                            <td> '.$linhap['id_paciente'] .' </td>
                                            <td> '.$linhap['nome'] .' </td>
                                            <td> '.$linhap['telefone'] .' </td>
                                            <td> '.$linhap['idade'] .' </td>
                                            <td> '.$linhap['cpf'] .' </td>
                                            <td> '.$linhap['ocorrencia'] .' </td>
                                            <td> <a href="excluir_paciente_adm.php?id_paciente='.$linhap['id_paciente'].'"> Excluir <a> </td>
                                            <td> <a href="edit_paciente_adm.php?id='.$linhap['id_paciente'].'"> Alterar <a> </td>
                                        </tr>
                                    ';
                                }
                            }
                        ?>

            </tbody>
        </table>



                <a href="cadastrop.php">CADASTRAR OCORRENCIA</a>
</body>
</html>
</body>
</html>