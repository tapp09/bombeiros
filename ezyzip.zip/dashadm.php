<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>

<table border="1" class="tabela">
            <thead>
                <tr>
                    <th> Código </th>
                    <th> Nome </th>
                    <th> E-mail </th>
                    <th> Telefone</th>
                    <th> cpf </th>
                    <th colspan="5"> Ações </th>
                </tr>
            </thead>
            <tbody>
            <?php
                            include_once("listar_bombeiros.php");
                            if(!empty($lista_bombeiros)){
                                foreach($lista_bombeiros as $linha){
                                    echo ' <tr>
                                            <td> '.$linha['id'] .' </td>
                                            <td> '.$linha['nome'] .' </td>
                                            <td> '.$linha['email'] .' </td>
                                            <td> '.$linha['telefone'] .' </td>
                                            <td> '.$linha['cpf'] .' </td>
                                            <td> <a href="excluir_bombeiro.php?id='.$linha['id'].'"> Excluir <a> </td>
                                            <td> <a href="registro_edit.php?id='.$linha['id'].'"> Alterar <a> </td>
                                        </tr>
                                    ';
                                }
                            }
                        ?>

            </tbody>
        </table>
        <table border="1" class="tabela">
            <thead>
                <tr>
                    <th> Código </th>
                    <th> Nome </th>
                    <th> telefone </th>
                    <th> idade</th>
                    <th> cpf </th>
                    <th> Ocorrencia </th>
                    <th colspan="5"> Ações </th>
                </tr>
            </thead>
            <tbody>
            <?php
                            include_once("listar_paciente.php");
                            if(!empty($lista_pacientes)){
                                foreach($lista_pacientes as $linhap){
                                    echo ' <tr>
                                            <td> '.$linhap['id_paciente'] .' </td>
                                            <td> '.$linhap['nome'] .' </td>
                                            <td> '.$linhap['telefone'] .' </td>
                                            <td> '.$linhap['idade'] .' </td>
                                            <td> '.$linhap['cpf'] .' </td>
                                            <td> '.$linhap['ocorrencia'] .' </td>
                                            <td> <a href="excluir_paciente.php?id_paciente='.$linhap['id_paciente'].'"> Excluir <a> </td>
                                            <td> <a href="edit_paciente.php?id='.$linhap['id_paciente'].'"> Alterar <a> </td>
                                        </tr>
                                    ';
                                }
                            }
                        ?>

            </tbody>
        </table>
        <a href="cadastrop.php">INSERIR</a>
</body>
</html>