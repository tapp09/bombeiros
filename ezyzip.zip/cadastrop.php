<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="cadastrop.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag@2.0.1/dist/css/multi-select-tag.css">
<title>Bombeiros Voluntários</title>

</head>
<body>
<header>
   <img src="/bombeiros/images/logo_medicina.png" alt="Logo dos Bombeiros Voluntários">
   <h1>Bombeiros Voluntários</h1>
</header>
<div class="container">
  <form action="inserir.php" method="POST">
  <div class="form-group">
    <label for="nome">NOME PACIENTE</label>
    <input type="text" id="nome" name="nome" required>
  </div>
  <div class="form-group">
    <label for="cpf">CPF/RG</label>
    <input type="text" id="cpf" name="cpf" required>
  </div>
  <div class="form-group">
    <label for="idade">IDADE</label>
    <input type="text" id="idade" name="idade" required>
  </div>
  <div class="form-group">
    <label for="telefone">Telefone</label>
    <input type="text" id="telefone" name="telefone" required>
  </div>
  <div class="form-group checkbox-group">
    <label for="genero">SEXO</label>
    <input type="radio" name="genero" value="masculino"> M
    <input type="radio" name="genero" value="feminino"> F
    <div class="clear"></div>
  </div>
  <div class="separator"></div>
  <div class="form-group">
    <label for="nome-acompanhante">NOME ACOMPANHANTE </label>
    <input type="text" id="nome-acompanhante" name="nome-acompanhante">
  </div>
  <div class="form-group">
    <label for="idade-acompanhante">IDADE </label>
    <input type="text" id="idade-acompanhante" name="idade-acompanhante">
  </div>



  
  <div class="form-group">
        <label for="hospital">HOSPITAL</label>
        <input type="text" id="hospital" name="hospital" required>
      </div>
      <br>
      <div class="form-group">
        <label for="local">LOCAL OCORRÊNCIA</label>
        <textarea rows="4" cols="50" id="local" name="local" required class="lo"></textarea>
      </div>
      <br>
      <div class="form-group">
        <label for="data">DATA</label>
        <input type="date" id="data" name="data" required class="data">
      </div>



      <h2>TIPOS DE OCORRÊNCIAS</h2>
        <div class="separator"></div>
        <select name="ocorrencia" id="tpocorrencia" required>
          <option value="CAUSADO POR ANIMAIS">CAUSADO POR ANIMAIS</option>
          <option value="COM MEIO DE TRANSPORTE">COM MEIO DE TRANSPORTE</option>
          <option value="DESMORONAMENTO / DESLIZAMENTO">DESMORONAMENTO / DESLIZAMENTO</option>
          <option value="EMERGÊNCIA MÉDICA">EMERGÊNCIA MÉDICA</option>
          <option value="QUEDA DE ALTURA 2M">QUEDA DE ALTURA 2M</option>
          <option value="TENTATIVA DE SUICÍDIO">TENTATIVA DE SUICÍDIO</option>
          <option value="QUEDA PRÓPRIA ALTURA">QUEDA PRÓPRIA ALTURA</option>
          <option value="AFOGAMENTO">AFOGAMENTO</option>
          <option value="AGRESSÃO">AGRESSÃO</option>
          <option value="ATROPELAMENTO">ATROPELAMENTO</option>
          <option value="DOMÉSTICO">DOMÉSTICO</option>
          <option value="ESPORTIVO">ESPORTIVO</option>
          <option value="QUEDA BICICLETA">QUEDA BICICLETA</option>
          <option value="QUEDA MOTO">QUEDA MOTO</option>
          <option value="QUEDA NÍVEL +2M">QUEDA NÍVEL +2M</option>
          <option value="TRABALHO">TRABALHO</option>
          <option value="TRANSFERÊNCIA">TRANSFERÊNCIA</option>
          <option value="CHOQUE ELÉTRICO">CHOQUE ELÉTRICO</option>
          <option value="DESABAMENTO">DESABAMENTO</option>
          <option value="NENHUMA DAS OPÇÕES">NENHUMA DAS OPÇÕES</option>
        </select>


        <select name="problemas" id="problema" required>
    <option value="">Selecione o problema</option>
    <?php

    include("conecta.php");

    $query = $pdo->query("SELECT id, nome FROM problemas ORDER BY nome ASC");
    $registros = $query->fetchAll(PDO::FETCH_ASSOC);

    foreach($registros as $option) {
      ?>
        <option value="<?php echo $option['id']?>"><?php echo $option['nome']?></option>
        <?php
    }
    ?>
    </select>

    <select name="subproblema" id="subproblema" required>
      <option value="">Selecione o problema</option>
    </select>



    <h2>SINAIS E SINTOMAS</h2>
        <div class="separator"></div>
    

        <select name="sinais" id="sinais" required>
        <option value="">Selecione os sinais</option>
        <?php

          include("conecta.php");

          $query = $pdo->query("SELECT id, sintomas FROM sinais ORDER BY sintomas ASC");
          $registros = $query->fetchAll(PDO::FETCH_ASSOC);

          foreach($registros as $option) {
            ?>
              <option value="<?php echo $option['id']?>"><?php echo $option['sintomas']?></option>
              <?php
          }
          ?>
          </select>

          <select name="subsinais" id="subsinais" required>
      <option value="">Selecione o sinais</option>
    </select>




          <h2>AVALIAÇÃO DO PACIENTE</h2>
          <div class="separator"></div>

          <input type="radio"  id="menor" name="ava_idade" onclick="hideshow(1)" value="MENORES DE 5 ANOS" ><label>MENORES DE 5 ANOS</label>
          <br>
          <input type="radio"  id="maior" name="ava_idade" onclick="hideshow(2)" value="MAIORES DE 5 ANOS"><label>MAIORES DE 5 ANOS</label>
          

          

          <div class="ava1">
            <h4>ABERTURA OCULAR</h4>
            <input type="radio" name="ocular" value="ESPONTÂNEA"><label>ESPONTÂNEA</label>
            <br>
            <input type="radio" name="ocular" value="COMANDO VERBAL"><label>COMANDO VERBAL</label>
            <br>
            <input type="radio" name="ocular" value="ESTIMULO DOLOROSO"><label>ESTIMULO DOLOROSO</label>
            <br>
            <input type="radio" name="ocular" value="NENHUMA"><label>NENHUMA</label>
            <br>
            <h4>RESPOSTA VERBAL</h4>
            <input type="radio" name="verbal" value="ORIENTADO"><label>ORIENTADO</label>
            <br>
            <input type="radio" name="verbal" value="CONFUSO"><label>CONFUSO</label>
            <br>
            <input type="radio" name="verbal" value="PALAVRAS INAPROPRIADAS"><label>PALAVRAS INAPROPRIADAS</label>
            <br>
            <input type="radio" name="verbal" value="PALAVRAS INCOMPRIENSSIVEIS"><label>PALAVRAS INCOMPRIENSSIVEIS</label>
            <br>
            <input type="radio" name="verbal" value="NENHUMA"><label>NENHUMA</label>
            <br>
            <h4>RESPOSTA MOTORA</h4>
            <input type="radio" name="motora" value="OBEDECE COMANDOS"><label>OBEDECE COMANDOS</label>
            <br>
            <input type="radio" name="motora" value="LOCALIZA DOR"><label>LOCALIZA DOR</label>
            <br>
            <input type="radio" name="motora" value="MOVIMENTOS DE RETIRADA"><label>MOVIMENTOS DE RETIRADA</label>
            <br>
            <input type="radio" name="motora" value="FLEXÃO ANORMAL"><label>FLEXÃO ANORMAL</label>
            <br>
            <input type="radio" name="motora" value="EXTENSÃO ANORMAL"><label>EXTENSÃO ANORMAL</label>
            <br>
            <input type="radio" name="motora" value="NENHUMA"><label>NENHUMA</label>
          </div>
          
          <br>
          <div class="ava2">
            <h4>ABERTURA OCULAR</h4>
            <input type="radio" name="ocular" value="ESPONTÂNEA"><label>ESPONTÂNEA</label>
            <br>
            <input type="radio" name="ocular" value="COMANDO VERBAL"><label>COMANDO VERBAL</label>
            <br>
            <input type="radio" name="ocular" value="ESTIMULO DOLOROSO"><label>ESTIMULO DOLOROSO</label>
            <br>
            <input type="radio" name="ocular" value="NENHUMA"><label>NENHUMA</label>
            <br>
            <h4>RESPOSTA VERBAL</h4>
            <input type="radio" name="verbal" value="PALAVRAS E FRASES APROPRIADAS"><label>PALAVRAS E FRASES APROPRIADAS</label>
            <br>
            <input type="radio" name="verbal" value="CHORO PERSISTENTE OU GRITO"><label>CHORO PERSISTENTE OU GRITO</label>
            <br>
            <input type="radio" name="verbal" value="PALAVRAS INAPROPRIADAS"><label>PALAVRAS INAPROPRIADAS</label>
            <br>
            <input type="radio" name="verbal" value="SONS INCOMPRIENSSIVEIS"><label>SONS INCOMPRIENSSIVEIS</label>
            <br>
            <input type="radio" name="verbal" value="NENHUMA RESPOSTA VERBAL"><label>NENHUMA RESPOSTA VERBAL</label>
            <h4>RESPOSTA MOTORA</h4>
            <input type="radio" name="motora" value="OBEDECE PRONTAMENTE"><label>OBEDECE PRONTAMENTE</label>
            <br>
            <input type="radio" name="motora" value="LOCALIZA DOR OU ESTIMULO TATIL"><label>LOCALIZA DOR OU ESTIMULO TATIL</label>
            <br>
            <input type="radio" name="motora" value="RETIRADA DO SEGMENTO ESTIMULADO"><label>RETIRADA DO SEGMENTO ESTIMULADO</label>
            <br>
            <input type="radio" name="motora" value="FLEXÃO ANORMAL"><label>FLEXÃO ANORMAL</label>
            <br>
            <input type="radio" name="motora" value="EXTENSÃO ANORMAL"><label>EXTENSÃO ANORMAL</label>
            <br>
            <input type="radio" name="motora" value="NENHUMA"><label>NENHUMA</label>
          </div>
          


          <h2>SINAIS VITAIS</h2>
        <div class="separator"></div>

  <div class="form-group">
    <label for="pa">PRESSÃO ARTERIAL</label>
    <input placeholder="mmHg" type="text" id="pa" name="pa" required>
  </div>
  <div class="form-group">
    <label for="pulso">PULSO</label>
    <input placeholder="B.C.P.M" type="text" id="pulso" name="pulso" required>
  </div>
  <div class="form-group">
    <label for="resp">RESPIRAÇÃO</label>
    <input placeholder="M.R.M" type="text" id="resp" name="resp" required>
  </div>
  <div class="form-group">
    <label for="sat">SATURAÇÃO</label>
    <input placeholder="%" type="text" id="sat" name="sat" required>
  </div>
  <div class="form-group">
    <label for="hgt">HGT </label>
    <input type="text" id="hgt" name="hgt">
  </div>

    <input type="radio"  id="normal" name="condicao" value="Normal" ><label>Normal</label>
          <br>
    <input type="radio"  id="anormal" name="condicao" value="Anormal"><label>Anormal</label>
          

  <div class="form-group">
      <label for="temp">TEMPERATURA </label>
      <input placeholder="°C" type="text" id="temp" name="temp">
    </div>
    <div class="form-group">
      <label for="perf">PERFUSÃO </label>
    </div>
    
    <input type="radio"  id="2seg" name="perfusao" value="-2SEG" ><label>-2SEG</label>
            <br>
      <input type="radio"  id="2seg1" name="perfusao" value="+2SEG"><label>+2SEG</label>
              <br>
              <br>
      <div class="btn_frente" onclick="hideshowcorpo(1)" >
        <input type="checkbox"  id="frente_corpo" name="frente_corpo" value="FRENTE" ><label>FRENTE</label>
      </div>
      <br>
      <div class="btn_costas" onclick="hideshowcorpo(2)">
        <input type="checkbox"  id="costas_corpo" name="costas_corpo" value="COSTAS"><label>COSTAS</label>
      </div>
      
          

        <div class="corpo">
          <div class="corpo1">
            <div class="img_corpo"></div>
            <div class="opts_corpo">
              <div class="opt_corpo">
              <input type="checkbox"  id="cabeca" name="cabeca_frente" value="CABEÇA"><label>CABEÇA</label>
              </div>
              <div class="opt_corpo">
              <input type="checkbox"  id="peito" name="peito_frente" value="PEITO"><label>PEITO</label>
              </div>
              <div class="opt_corpo">
              <input type="checkbox"  id="braco1" name="braco1_frente" value="BRAÇO DIREITO"><label>BRAÇO DIREITO</label>
              </div>
              <div class="opt_corpo">
              <input type="checkbox"  id="braco2" name="braco2_frente" value="BRAÇO ESQUERDO"><label>BRAÇO DIREITO</label>
              </div>
              <div class="opt_corpo">
              <input type="checkbox"  id="abdomen" name="abdomen_frente" value="ABDOMEN"><label>ABDOMEN</label>
              </div>
              <div class="opt_corpo">
              <input type="checkbox"  id="genitalia" name="genitalia_frente" value="GENITALIA"><label>GENITALIA</label>
              </div>
              <div class="opt_corpo">
              <input type="checkbox"  id="perna1" name="perna1_frente" value="PERNA DIREITA"><label>PERNA DIREITA</label>
              </div>
              <div class="opt_corpo">
              <input type="checkbox"  id="perna2" name="perna2_frente" value="PERNA ESQUERDA"><label>PERNA ESQUERDA</label>
              </div>
            </div>
          </div>
          <div class="corpo2">
            <div class="img_corpo"></div>
            <div class="opts_corpo">
              <div class="opt_corpo">
                <input type="checkbox"  id="cabeca" name="cabeca" value="CABEÇA"><label>CABEÇA</label>
                </div>
                <div class="opt_corpo">
                <input type="checkbox"  id="costas" name="costas" value="COSTAS"><label>COSTAS</label>
                </div>
                <div class="opt_corpo">
                <input type="checkbox"  id="braco1" name="braco1" value="BRAÇO DIREITO"><label>BRAÇO DIREITO</label>
                </div>
                <div class="opt_corpo">
                <input type="checkbox"  id="braco2" name="braco2" value="BRAÇO ESQUERDO"><label>BRAÇO DIREITO</label>
                </div>
                <div class="opt_corpo">
                <input type="checkbox"  id="bunda" name="bunda" value="BUNDA"><label>BUNDA</label>
                </div>
                <div class="opt_corpo">
                <input type="checkbox"  id="perna1" name="perna1" value="PERNA DIREITA"><label>PERNA DIREITA</label>
                </div>
                <div class="opt_corpo">
                <input type="checkbox"  id="perna2" name="perna2" value="PERNA ESQUERDA"><label>PERNA ESQUERDA</label>
                </div>
              </div>        
          </div>
          <select name="prt_corpo" id="prt_corpo" multiple>
                  <option value="FRATURAS">FRATURAS</option>
                  <option value="FERIMENTOS DIV.">FERIMENTOS DIV.</option>
                  <option value="HEMORRAGIA">HEMORRAGIA</option>
                  <option value="ESVICERAÇÃO">ESVICERAÇÃO</option>
                  <option value="F.A.B / F.A.F">F.A.B / F.A.F</option>
                  <option value="AMPUTAÇÃO">AMPUTAÇÃO</option>
                  <option value="QUEIMADURA 1GRAU">QUEIMADURA 1GRAU</option>
                  <option value="QUEIMADURA 2GRAU">QUEIMADURA 2GRAU</option>
                  <option value="QUEIMADURA 3GRAU">QUEIMADURA 3GRAU</option>
                </select>
        </div>

        <h2>QUEIMADURAS</h2>
        <div class="separator"></div>
        <h3>1º GRAU</h3>
        <div class="checkbox-list">
            <label><input name="cabeca_q" type="checkbox" value="CABEÇA"><span class="queimaduras">CABEÇA</span></label>
            <label><input name="pescoco_q" type="checkbox" value="PESCOÇO"><span class="queimaduras">PESCOÇO</span></label>
            <label><input name="t_ant_q" type="checkbox" value="T.ANT"><span class="queimaduras">T. ANT</span></label>
            <label><input name="t_pos_q" type="checkbox" value="T.POS"><span class="queimaduras">T. POS</span></label>
            <label><input name="genitais_q" type="checkbox" value="GENITAIS"><span class="queimaduras">GENITAIS</span></label>
            <label><input name="m_i_d_q" type="checkbox" value="M.I.D"><span class="queimaduras">M.I.D</span></label>
            <label><input name="m_i_e_q" type="checkbox" value="M.I.E"><span class="queimaduras">M.I.E</span></label>
            <label><input name="m_s_d_q" type="checkbox" value="M.S.D"><span class="queimaduras">M.S.D</span></label>
            <label><input name="m_s_e_q" type="checkbox" value="M.S.E"><span class="queimaduras">M.S.E</span></label>
        </div>
        <div class="separator"></div>
        <h3>2º GRAU</h3>
        <div class="checkbox-list">
            <label><input name="cabeca_qdois" type="checkbox" value="CABEÇA"><span class="queimaduras">CABEÇA</span></label>
            <label><input name="pescoco_qdois" type="checkbox" value="PESCOÇO"><span class="queimaduras">PESCOÇO</span></label>
            <label><input name="t_ant_qdois" type="checkbox" value="T.ANT"><span class="queimaduras">T. ANT</span></label>
            <label><input name="t_pos_qdois" type="checkbox" value="T.POS"><span class="queimaduras">T. POS</span></label>
            <label><input name="genitais_qdois" type="checkbox" value="GENITAIS"><span class="queimaduras">GENITAIS</span></label>
            <label><input name="m_i_d_qdois" type="checkbox" value="M.I.D"><span class="queimaduras">M.I.D</span></label>
            <label><input name="m_i_e_qdois" type="checkbox" value="M.I.E"><span class="queimaduras">M.I.E</span></label>
            <label><input name="m_s_d_qdois" type="checkbox" value="M.S.D"><span class="queimaduras">M.S.D</span></label>
            <label><input name="m_s_e_qdois" type="checkbox" value="M.S.E"><span class="queimaduras">M.S.E</span></label>
        </div>
        <div class="separator"></div>
        <h3>3º GRAU</h3>
        <div class="checkbox-list">
            <label><input name="cabeca_qtres" type="checkbox" value="CABEÇA"><span class="queimaduras">CABEÇA</span></label>
            <label><input name="pescoco_qtres" type="checkbox" value="PESCOÇO"><span class="queimaduras">PESCOÇO</span></label>
            <label><input name="t_ant_qtres" type="checkbox" value="T.ANT"><span class="queimaduras">T. ANT</span></label>
            <label><input name="t_pos_qtres" type="checkbox" value="T.POS"><span class="queimaduras">T. POS</span></label>
            <label><input name="genitais_qtres" type="checkbox" value="GENITAIS"><span class="queimaduras">GENITAIS</span></label>
            <label><input name="m_i_d_qtres" type="checkbox" value="M.I.D"><span class="queimaduras">M.I.D</span></label>
            <label><input name="m_i_e_qtres" type="checkbox" value="M.I.E"><span class="queimaduras">M.I.E</span></label>
            <label><input name="m_s_d_qtres" type="checkbox" value="M.S.D"><span class="queimaduras">M.S.D</span></label>
            <label><input name="m_s_e_qtres" type="checkbox" value="M.S.E"><span class="queimaduras">M.S.E</span></label>
        </div>


        <h2>TRANSPORTE</h2>
        <div class="separator"></div>
        <h3>FORMA DE CONDUÇÃO</h3>
            <div class="checkbox-list">
                <label><input type="radio" name="conducao" value="DEITADA"><span class="fconducao">DEITADA</span></label>
                <label><input type="radio" name="conducao" value="SEMI-SENTADA"><span class="fconducao">SEMI-SENTADA</span></label>
                <label><input type="radio" name="conducao" value="SENTADA"><span class="fconducao">SENTADA</span></label>

            </div>
            <br>
            <div class="separator"></div>
            <h3>DECISÃO DE TRANSPORTE</h3>
          <div class="checkbox-list">
            <label><input type="radio" name="decisao" value="CRÍTICO"><span class="dtrans">CRÍTICO</span></label>
            <label><input type="radio" name="decisao" value="INSTÁVEL"><span class="dtrans">INSTÁVEL</span></label>
            <label><input type="radio" name="decisao" value="PARCIALMENTE INSTÁVEL"><span class="dtrans">PARCIALMENTE INSTÁVEL</span></label>
            <label><input type="radio" name="decisao" value="ESTAVEL"><span class="dtrans">ESTAVEL</span></label>
          </div>


          <h2>VÍTIMA ERA</h2>
        <div class="separator"></div>
    <div class="checkbox-list">
        <label><input name="vitima" value="PEDESTRE" type="radio"><span class="vitima">PEDESTRE</span></label>
        <br/>
        <label><input name="vitima" value="CICLISTA" type="radio"><span class="vitima">CICLISTA</span></label>
        <br/>
        <label><input name="vitima" value="CONDUTOR MOTO" type="radio"><span class="vitima">CONDUTOR MOTO</span></label>
        <br/>
        <label><input name="vitima" value="PASSAGEIRO MOTO" type="radio"><span class="vitima">PASSAGEIRO MOTO</span></label>
        <br/>
        <label><input name="vitima" value="CONDUTOR CARRO" type="radio"><span class="vitima">CONDUTOR CARRO</span></label>
        <br/>
        <label><input name="vitima" value="PASSAGEIRO CARRO" type="radio"><span class="vitima">PASSAGEIRO CARRO</span></label>
        <br/>
        <label><input name="vitima" value="PASSAGEIRO BANCO TRÁS" type="radio"><span class="vitima">PASSAGEIRO BANCO TRÁS</span></label>
        <br/>
        <label><input name="vitima" value="GESTANTE" type="radio"><span class="vitima">GESTANTE</span></label>
        <br/>
        <label><input name="vitima" value="CLÍNICO" type="radio"><span class="vitima">CLÍNICO</span></label>
        <br/>
        <label><input name="vitima" value="TRAUMA" type="radio"><span class="vitima">TRAUMA</span></label>
    </div>




    <h2>OBJETOS RECOLHIDOS</h2>
        <div class="separator"></div>
        <div class="checkbox-list">
            <label><input name="objeto" value="NENHUM" type="radio"><span class="objetos">NENHUM</span></label>
            <label><input name="objeto" value="SIM" type="radio" id="outrosCheckboxobj"><span class="objetos">SIM</span></label>
            <textarea id="outrosInputobj" name="objetostxt" class="outros-input text-input" rows="16" placeholder="Informe os objetos" disabled></textarea>
        </div>




        <h2>EQUIPE DE ATENDIMENTO</h2>
        <div class="separator"></div>
        <div class="form-group">
            <label for="medico">M</label>
            <input type="text" id="medico" name="medico">
          </div>
          <div class="form-group">
            <label for="s1">S1</label>
            <input type="text" id="s1" name="s1">
          </div>
          <div class="form-group">
            <label for="s2">S2</label>
            <input type="text" id="s2" name="s2">
          </div>
          <div class="form-group">
            <label for="s3">S3</label>
            <input type="text" id="s3" name="s3">
          </div>
          <div class="form-group">
            <label for="demandante">DEMANDANTE</label>
            <input type="text" id="demandante" name="demandante">
          </div>
          <div class="form-group">
            <label for="equipe">EQUIPE</label>
            <input type="text" id="equipe" name="equipe">
          </div>







          <h2>PROCEDIMENTOS EFETUADOS</h2>
        <div class="separator"></div>
    <div class="checkbox-list">
    <label><input type="checkbox" value="ASPIRAÇÃO" name="aspiracao"><span class="procedimentos">ASPIRAÇÃO</span></label>
    <br/>
    <label><input type="checkbox" value="AVALIAÇÃO INICIAL" name="avaliacao_inicial"><span class="procedimentos">AVALIAÇÃO INICIAL</span></label>
    <br/>
    <label><input type="checkbox" value="AVALIAÇÃO DIRIGIDA" name="avaliacao_dirigida"><span class="procedimentos">AVALIAÇÃO DIRIGIDA</span></label>
    <br/>
    <label><input type="checkbox" value="AVALIAÇÃO CONTINUADA" name="avaliacao_continuada"><span class="procedimentos">AVALIAÇÃO CONTINUADA</span></label>
    <br/>
    <label><input type="checkbox" value="CHAVE DE RAUTEK" name="chave_de_rautek"><span class="procedimentos">CHAVE DE RAUTEK</span></label>
    <br/>
    <label><input type="checkbox" value="CÂNULA DE GUEDEL" name="canula_de_guedel"><span class="procedimentos">CÂNULA DE GUEDEL</span></label>
    <br/>
    <label><input type="checkbox" value="DESOBSTRUÇÃO DE V.A" name="desobstrucao_de_va"><span class="procedimentos">DESOBSTRUÇÃO DE V.A</span></label>
    <br/>
    <label><input type="checkbox" value="EMPREGO DO D.E.A" name="emprego_do_dea"><span class="procedimentos">EMPREGO DO D.E.A</span></label>
    <br/>
    <label><input type="checkbox" value="GERENCIAMENTO DE RISCOS" name="gerenciamento_de_riscos"><span class="procedimentos">GERENCIAMENTO DE RISCOS</span></label>
    <br/>
    <label><input type="checkbox" value="LIMPEZA DE FERIMENTO" name="limpeza_de_ferimento"><span class="procedimentos">LIMPEZA DE FERIMENTO</span></label>
    <br/>
    <label><input type="checkbox" value="CURATIVOS" name="curativos"><span class="procedimentos">CURATIVOS</span></label>
    <br/>
    <label><input type="checkbox" value="COMPRESSIVO" name="compressivo"><span class="procedimentos">COMPRESSIVO</span></label>
    <br/>
    <label><input type="checkbox" value="ENCRAVAMENTO" name="encravamento"><span class="procedimentos">ENCRAVAMENTO</span></label>
    <br/>
    <label><input type="checkbox" value="OCULAR" name="ocular"><span class="procedimentos">OCULAR</span></label>
    <br/>
    <label><input type="checkbox" value="QUEIMADURA" name="queimadura"><span class="procedimentos">QUEIMADURA</span></label>
    <br/>
    <label><input type="checkbox" value="SIMPLES" name="simples"><span class="procedimentos">SIMPLES</span></label>
    <br/>
    <label><input type="checkbox" value="3 PONTAS" name="3_pontas"><span class="procedimentos">3 PONTAS</span></label>
    <br/>
    <label><input type="checkbox" value="IMOBILIZAÇÕES" name="imobilizacoes"><span class="procedimentos">IMOBILIZAÇÕES</span></label>
    <br/>
    <label><input type="checkbox" value="MEMBRO INF.DIR." name="membr_infd"><span class="procedimentos">MEMBRO INF.DIR.</span></label>
    <br/>
    <label><input type="checkbox" value="MEMBRO INF.ESQ." name="membr_infesq"><span class="procedimentos">MEMBRO INF.ESQ.</span></label>
    <br/>
    <label><input type="checkbox" value="MEMBRO SUP. DIR." name="membr_supdir"><span class="procedimentos">MEMBRO SUP. DIR.</span></label>
    <br/>
    <label><input type="checkbox" value="MEMBRO SUP. ESQ." name="membr_supesq"><span class="procedimentos">MEMBRO SUP. ESQ.</span></label>
    <br/>
    <label><input type="checkbox" value="QUADRIL" name="quadril"><span class="procedimentos">QUADRIL</span></label>
    <br/>
    <label><input type="checkbox" value="CERVICAL" name="cervical"><span class="procedimentos">CERVICAL</span></label>
    <br/>
    <label><input type="checkbox" value="MACA SOBRE RODAS" name="maca_sobre_rodas"><span class="procedimentos">MACA SOBRE RODAS</span></label>
    <br/>
    <label><input type="checkbox" value="MACA RÍGIDA" name="maca_rigida"><span class="procedimentos">MACA RÍGIDA</span></label>
    <br/>
    <label><input type="checkbox" value="PONTE" name="ponte"><span class="procedimentos">PONTE</span></label>
    <br/>
    <label><input type="checkbox" value="RETIRADO CAPACETE" name="retirado_capacete"><span class="procedimentos">RETIRADO CAPACETE</span></label>
    <br/>
    <label><input type="checkbox" value="R.C.P." name="rcp"><span class="procedimentos">R.C.P.</span></label>
    <br/>
    <label><input type="checkbox" value="ROLAMENTO 90°" name="rolamento_90"><span class="procedimentos">ROLAMENTO 90°</span></label>
    <br/>
    <label><input type="checkbox" value="ROLAMENTO 180°" name="rolamento_180"><span class="procedimentos">ROLAMENTO 180°</span></label>
    <br/>
    <label><input type="checkbox" value="TOMADA DECISÃO" name="tomada_decisao"><span class="procedimentos">TOMADA DECISÃO</span></label>
    <br/>
    <label><input type="checkbox" value="TRATADO CHOQUE" name="tratado_choque"><span class="procedimentos">TRATADO CHOQUE</span></label>
    <br/>
    <label><input type="checkbox" value="USO DE CÂNULA" name="uso_de_canula"><span class="procedimentos">USO DE CÂNULA</span></label>
    <br/>
    <label><input type="checkbox" value="USO COLAR" name="uso_colar"><span class="procedimentos">USO COLAR</span></label>
    


        <div class="form-group">
            <label for="tam">TAM</label>
            <input type="text" id="tam" name="tam">
        </div>

        <label><input type="checkbox" value="USO KED" name="uso_ked"><span class="procedimentos">USO KED</span></label>
        <br/>
        <label><input type="checkbox" value="USO TTF" name="uso_ttf"><span class="procedimentos">USO TTF</span></label>
        <br/>
        <label><input type="checkbox" value="VENTILAÇÃO SUPORTE" name="ventilacao_suporte"><span class="procedimentos">VENTILAÇÃO SUPORTE</span></label>
        <br/>
        <label><input type="checkbox" value="OXIGENIOTERAPIA" name="oxigenioterapia"><span class="procedimentos">OXIGENIOTERAPIA</span></label>

        <div class="form-group">
            <label for="olpm">LPM:</label>
            <input type="text" id="olpm" name="olpm">
        </div>

        <label><input type="checkbox" value="REANIMADOR" name="reanimador"><span class="procedimentos">REANIMADOR</span></label>
        <div class="form-group">
            <label for="rlpm">LPM:</label>
            <input type="text" id="rlpm" name="rlpm">
        </div>


        <label><input type="checkbox" value="MEIOS AUXILIARES" name="auxiliar"><span class="procedimentos">MEIOS AUXILIARES</span></label>
        <br/>
        <div class="suboptions auxiliares">
        <label><input type="checkbox" value="CELESC" name="celesc"><span class="procedimentos">CELESC</span></label>
        <br/>
        <label><input type="checkbox" value="DEF. CIVIL" name="def_civil"><span class="procedimentos">DEF. CIVIL</span></label>
        <br/>
        <label><input type="checkbox" value="IGP / PO" name="igp_po"><span class="procedimentos">IGP / PO</span></label>
        <br/>
        <label><input type="checkbox" value="POLICIA CIVIL" name="policia_civil"><span class="procedimentos">POLICIA CIVIL</span></label>
        <br/>
        <label><input type="checkbox" value="POLICIA MILITAR" name="policia_militar"><span class="procedimentos">POLICIA MILITAR</span></label>
        <br/>
        <label><input type="checkbox" value="PRE" name="pre"><span class="procedimentos">PRE</span></label>
        <br/>
        <label><input type="checkbox" value="PRF" name="prf"><span class="procedimentos">PRF</span></label>
        <br/>
        <label><input type="checkbox" value="CIT" name="cit"><span class="procedimentos">CIT</span></label>
        <br/>
        <label><input type="checkbox" value="SAMU - USA" name="samu_usa"><span class="procedimentos">SAMU - USA</span></label>
        <br/>
        <label><input type="checkbox" value="SAMU - USB" name="samu_usb"><span class="procedimentos">SAMU - USB</span></label>

        </div>



        <h2>MATERIAIS UTILIZADOS DESCARTÁVEL</h2>
            <div class="separator"></div>
            <div class="checkbox-list">
                <label>
                    <input type="checkbox" name="atadura" value="ATADURA"><span class="materiais-label">ATADURAS</span>
                    
                    <input type="text" name="qtd_atadura" class="text-input" placeholder="Quant.">
                </label>
                <br/>
                <div class="suboptions ataduras">
                    <label><input type="radio" name="tip_atadura" value="8"><span class="materiais">8</span></label>
                    <label><input type="radio" name="tip_atadura" value="12"><span class="materiais">12</span></label>
                    <label><input type="radio" name="tip_atadura" value="20"><span class="materiais">20</span></label>
                </div>
                <br/>
        
                <label>
                    <input type="checkbox" name="cateter" value="CATETER"><span class="materiais">CATETER TP. OCÚLOS</span>
                    <input type="text" class="text-input" name="qtd_cateter" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="compressa" value="COMPRESSA"><span class="materiais">COMPRESSA COMUM</span>
                    <input type="text" class="text-input" name="qtd_compressa" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="kits" value="KITS"><span class="materiais">KITS</span>
                    <input type="text" class="text-input" name="qtd_kits" placeholder="Quant.">
                </label>
                <br/>
                <div class="suboptions kits">
                    <label><input type="radio" name="tip_kits" value="H"><span class="materiais">H</span></label>
                    <label><input type="radio" name="tip_kits" value="P"><span class="materiais">P</span></label>
                    <label><input type="radio" name="tip_kits" value="Q"><span class="materiais">Q</span></label>
                </div>
                <br/>
                <label>
                    <input type="checkbox" name="luvas" value="LUVAS"><span class="materiais">LUVAS DESCARTÁVEIS</span>
                    <input type="text" class="text-input" name="qtd_luvas" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="mascara" value="MASCARA"><span class="materiais">MÁSCARA DESCARTÁVEIS</span>
                    <input type="text" class="text-input" name="qtd_mascara" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="manta" value="MANTA"><span class="materiais">MANTA ALUMINIZADA</span>
                    <input type="text" class="text-input" name="qtd_manta" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="pas" value="PÁS DO DEA"><span class="materiais" >PÁS DO DEA</span>
                    <input type="text" class="text-input" name="qtd_pas" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="soro" value="SORO"><span class="materiais">SORO FISIOLÓGICO</span>
                    <input type="text" class="text-input" name="qtd_soro" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="tala" value="TALA"><span class="materiais">TALAS PAP.</span>
                    <input type="text" class="text-input" name="qtd_tala" placeholder="Quant.">
                </label>
                <div class="suboptions talas">
                    <label><input type="radio" name="tip_tala" value="P"><span class="materiais">P</span></label>
                    <label><input type="radio" name="tip_tala" value="G"><span class="materiais">G</span></label>
                    <br/><br/>
                <input type="text" id="outrosInput" name="outro_mat" class="outros-input" placeholder="Informe outros materias">
            </div>
        </div>
        <div class="separator"></div>
        <h2>MATERIAIS UTILIZADOS DEIXADOS NO HOSPITAL</h2>
            <div class="separator"></div>
            <div class="checkbox-list">
                <label>
                    <input type="checkbox" name="base" value="BASE DO ESTABILIZA"><span class="materiais-label">BASE DO ESTABILIZA</span>
                    <input type="text" class="text-input" name="qtd_base" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="colar" value="COLAR"><span class="materiais-label">COLAR</span>
                    <input type="text" class="text-input" name="qtd_colar" placeholder="Quant.">
                </label>
                <div class="suboptions colar">
                    <label><input type="radio" name="tip_colar" value="N"><span class="materiais">N</span></label>
                    <label><input type="radio" name="tip_colar" value="PP"><span class="materiais">PP</span></label>
                    <label><input type="radio" name="tip_colar" value="P"><span class="materiais">P</span></label>
                    <label><input type="radio" name="tip_colar" value="M"><span class="materiais">M</span></label>
                    <label><input type="radio" name="tip_colar" value="G"><span class="materiais">G</span></label>
                </div>
                <br/>
                <label>
                    <input type="checkbox" name="coxin" value="COXINS ESTABILIZA"><span class="materiais-label">COXINS ESTABILIZA</span>
                    <input type="text" class="text-input" name="qtd_coxin" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="ked" value="KED"><span class="materiais-label">KED</span>
                    <input type="text" class="text-input" name="qtd_ked" placeholder="Quant.">
                </label>
                <div class="suboptions ked">
                    <label><input type="radio" name="tip_ked" value="ADULTO"><span class="materiais">ADULTO</span></label>
                    <label><input type="radio" name="tip_ked" value="INFANTIL"><span class="materiais">INFANTIL</span></label>
                </div>
                <br/>
                <label>
                    <input type="checkbox" name="maca" value="MACA RIGIDA"><span class="materiais-label">MACA RIGIDA</span>
                    <input type="text" class="text-input" name="qtd_maca" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="t_t_f" value="T.T.F"><span class="materiais-label">T.T.F</span>
                    <input type="text" class="text-input" name="qtd_t_t_f" placeholder="Quant.">
                </label>
                <div class="suboptions ttf">
                    <label><input type="checkbox" name="tip_t_t_f" value="ADULTO"><span class="materiais">ADULTO</span></label>
                    <label><input type="checkbox" name="tip_t_t_f" value="INFANTIL"><span class="materiais">INFANTIL</span></label>
                </div>
                <br/>
                <label>
                    <input type="checkbox" name="tirante_aranha" value="TIRANTE ARANHA"><span class="materiais-label">TIRANTE ARANHA</span>
                    <input type="text" class="text-input" name="qtd_tirante" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="tirante_cabeca" value="TIRANTE DE CABEÇA"><span class="materiais-label">TIRANTE DE CABEÇA</span>
                    <input type="text" class="text-input" name="qtd_tirantedois" placeholder="Quant.">
                </label>
                <br/><br/>
                <label>
                    <input type="checkbox" name="canula" value="CÂNULA"><span class="materiais-label">CÂNULA</span>
                    <input type="text" class="text-input" name="qtd_canula" placeholder="Quant.">
                </label>




                <h2>ANAMNESE DA EMERGÊNCIA MÉDICA</h2>
        <div class="separator"></div>
        <div class="form-group">
            <label for="acontecimento">O QUE ACONTECEU</label>
            <textarea id="outrosInputobj" name="ocorrido" class="outros-input text-input" rows="10" placeholder="Informe o ocorrido"></textarea>
          </div>
<BR>
          <label><span class="aov">ACONTECEU OUTRAS VEZES?</span></label>
        <div class="suboptions">
            <label><input type="radio" name="conf" value="SIM"><span class="aov">SIM</span></label>
            <label><input type="radio" name="conf" value="NÃO"><span class="aov">NÃO</span></label>
        </div>

        <br><br>

        <div class="form-group">
            <label for="tempo">A QUANTO TEMPO ISSO ACONTECEU</label>
            <input type="text" name="tempo" id="tempo" >
          </div>

          <br><br>

          <label><span class="aov">POSSUI PROBLEMAS DE SAUDE?</span></label>
          <div class="suboptions">
              <label><input type="checkbox" name="confdois" value="SIM"><span class="aov">SIM</span></label>
              <label><input type="checkbox" name="confdois" value="NÃO"><span class="aov">NÃO</span></label>
          </div>

          <br><br>

          <div class="form-group">
            <label for="quais">QUAIS PROBLEMAS?</label>
            <input type="text" name="problemas" id="quais" >
          </div>

          <br><br>

          <label><span class="aov">FAZ USO DE MEDICAÇÃO?</span></label>
          <div class="suboptions">
              <label><input type="checkbox" name="conftres" value="SIM"><span class="aov">SIM</span></label>
              <label><input type="checkbox" name="conftres" value="NÃO"><span class="aov">NÃO</span></label>
          </div>

        <BR><br>

    <div class="form-group">
        <label for="med">HORÁRIO ÚLTIMA MEDICAÇÃO</label>
        <input type="text" name="medicacao" id="med" name="med">
      </div>

      <BR><br>

        <div class="form-group">
            <label for="quais">QUAIS MEDICAMENTOS?</label>
            <input type="text" name="medicamentos" id="quais" >
          </div>

          <BR><br>

            <label><span class="aov">ALÉRGICO A ALGUMA COISA?</span></label>
            <div class="suboptions">
                <label><input type="checkbox" name="confquatro" value="SIM"><span class="aov">SIM</span></label>
                <label><input type="checkbox" name="confquatro" value="NÃO"><span class="aov">NÃO</span></label>
            </div>

<BR>

    <div class="form-group">
        <label for="quais">SE SIM, ESPECIFIQUE?</label>
        <input type="text" name="especificar" id="quais">
      </div>

      <BR>

        <label><span class="aov">INGERIU ALIMENTO OU LÍQUIDO ≥6 HORAS?</span></label>
            <div class="suboptions">
                <label><input type="checkbox" name="confcinco" value="SIM"><span class="aov">SIM</span></label>
                <label><input type="checkbox" name="confcinco" value="NÃO"><span class="aov">NÃO</span></label>
            </div>

<BR>

    <div class="form-group">
        <label for="horaalimento">QUE HORAS?</label>
        <input type="text" id="horaalimento" name="horaalimento">
      </div>
    </div>



    
  
    <h2>ANAMNESE GESTACIONAL</h2>
        <div class="separator"></div>
    <div class="checkbox-list">
        <div class="form-group">
            <label><span class="gestacao">PERÍODO DA GESTAÇÃO</span></label>
            <input type="text" id="gestacao" name="gestacao">
          </div>

          <br>

          <div class="form-group">
          <label><span class="gestacional">FEZ PRÉ-NATAL?</span></label>
          <div class="suboptions">
              <label><input type="radio" name="prenatal" value="SIM"><span class="gestacional">SIM</span></label>
              <label><input type="radio" name="prenatal" value="NÃO"><span class="gestacional">NÃO</span></label>
          </div>
          </div>
          
        

          <div class="form-group">
            <label for="gestacao">NOME DO MÉDICO</label>
            <input type="text" id="gestacao" name="n_medico">
          </div>
        
          <br>

        <div class="form-group">
        <label><span class="gestacional">EXISTE POSSIBILIDADE DE COMPLICAÇÕES?</span></label>
          <div class="suboptions">
              <label><input type="radio" name="complicacoes" value="SIM"><span class="gestacional">SIM</span></label>
              <label><input type="radio" name="complicacoes" value="NÃO"><span class="gestacional">NÃO</span></label>
          </div>
        </div>

        <br>

        <div class="form-group">
          <label><span class="gestacional">É O PRIMEIRO FILHO?</span></label>
          <div class="suboptions">
              <label><input type="radio" name="filho" value="SIM"><span class="gestacional">SIM</span></label>
              <label><input type="radio" name="filho" value="NÃO"><span class="gestacional">NÃO</span></label>
          </div>
        </div>

   

          <div class="form-group">
            <label for="gestacao">QUANTOS?</label>
            <input type="text" id="gestacao" name="qtd">
          </div>
       
          <div class="form-group">
            <label for="gestacao">QUE HORAS INICIARAM AS CONTRAÇÕES?</label>
            <input type="text" id="gestacao" name="contracoes">
          </div>
    

        <div class="form-group">
            <label for="gestacao">DURAÇÃO:</label>
            <input type="text" id="gestacao" name="duracao">
          </div>
        

        <div class="form-group">
            <label for="gestacao">INTERVALO:</label>
            <input type="text" id="gestacao" name="intervalo">
          </div>
       
          <br>
        
        <label><span class="gestacional">PRESSÃO NA REGIÃO DO QUADRIL OU VONTADE DE EVACUAR?</span></label>
          <div class="suboptions">
              <label><input type="radio" name="pressao" value="SIM"><span class="gestacional">SIM</span></label>
              <label><input type="radio" name="pressao" value="NÃO"><span class="gestacional">NÃO</span></label>
          </div>
        
          <br>
        <div class="form-group">
          <label><span class="gestacional">JÁ HOUVE RUPTURA NA BOLSA?</span></label>
          <div class="suboptions">
              <label><input type="radio" name="bolsa" value="SIM"><span class="gestacional">SIM</span></label>
              <label><input type="radio" name="bolsa" value="NÃO"><span class="gestacional">NÃO</span></label>
          </div>
        </div>
        <br>
        <div class="form-group">
          <label><span class="gestacional">FOI FEITO INSPEÇÃO VISUAL?</span></label>
          <div class="suboptions">
              <label><input type="radio" name="inspecao" value="SIM"><span class="gestacional">SIM</span></label>
              <label><input type="radio" name="inspecao" value="NÃO"><span class="gestacional">NÃO</span></label>
          </div>
        </div>
        <br>
        <div class="form-group">
          <label><span class="gestacional">PARTO REALIZADO?</span></label>
          <div class="suboptions">
              <label><input type="radio" name="parto" value="SIM"><span class="gestacional">SIM</span></label>
              <label><input type="radio" name="parto" value="NÃO"><span class="gestacional">NÃO</span></label>
          </div>
        </div>
        
          <div class="form-group">
            <label for="gestacao">HORA NASCIMENTO</label>
            <input type="text" id="gestacao" name="nascimento">
          </div>
       

        <div class="form-group">
        <label><span class="gestacional">SEXO DO BEBE</span></label>
        <div class="suboptions">
            <label><input type="radio" name="sexo" value="FEM"><span class="gestacional">FEM</span></label>
            <label><input type="radio" name="sexo" value="MAS"><span class="gestacional">MAS</span></label>
        </div>
        </div>

        <div class="form-group">
            <label for="gestacao">NOME DO BEBE</label>
            <input type="text" id="gestacao" name="nome_bebe">
          </div>

          <br><br><br>



          <h2>AVALIAÇÃO DA CINEMÁTICA</h2>
        <div class="separator"></div>
        <div class="checkbox-list">
        <div class="form-group">
        <label><span class="cine">DISTÚRBIO DE COMPORTAMENTO</span></label>
        <div class="suboptions">
            <label><input type="radio" name="disturbio" value="SIM"><span class="cine">SIM</span></label>
            <label><input type="radio" name="disturbio" value="NÃO"><span class="cine">NÃO</span></label>
        </div>
        </div>

        <div class="form-group">
        <label><span class="cine">ENCONTRADO DE CAPACETE</span></label>
        <div class="suboptions">
            <label><input type="radio" name="capacete" value="SIM"><span class="cine">SIM</span></label>
            <label><input type="radio" name="capacete" value="NÃO"><span class="cine">NÃO</span></label>
        </div>
        </div>

        <div class="form-group">
        <label><span class="cine">ENCONTRADO DE CINTO</span></label>
        <div class="suboptions">
            <label><input type="radio" name="cinto" value="SIM"><span class="cine">SIM</span></label>
            <label><input type="radio" name="cinto" value="NÃO"><span class="cine">NÃO</span></label>
        </div>
        </div>

        <div class="form-group">
        <label><span class="cine">PARA-BRISAS AVARIADO</span></label>
        <div class="suboptions">
            <label><input type="radio" name="parabrisas" value="SIM"><span class="cine">SIM</span></label>
            <label><input type="radio" name="parabrisas" value="NÃO"><span class="cine">NÃO</span></label>
        </div>
        </div>

        <div class="form-group">
        <label><span class="cine">CAMINHANDO NA CENA</span></label>
        <div class="suboptions">
            <label><input type="radio" name="caminhando" value="SIM"><span class="cine">SIM</span></label>
            <label><input type="radio" name="caminhando" value="NÃO"><span class="cine">NÃO</span></label>
        </div>
    </div>

    <div class="form-group">
        <label><span class="cine">PAINEL AVARIADO</span></label>
        <div class="suboptions">
            <label><input type="radio" name="painel" value="SIM"><span class="cine">SIM</span></label>
            <label><input type="radio" name="painel" value="NÃO"><span class="cine">NÃO</span></label>
        </div>
    </div>

        <div class="form-group">
        <label><span class="cine">VOLANTE TORCIDO</span></label>
        <div class="suboptions">
            <label><input type="radio" name="volante" value="SIM"><span class="cine">SIM</span></label>
            <label><input type="radio" name="volante" value="NÃO"><span class="cine">NÃO</span></label>
        </div>
        </div>

        <h2>OBSERVAÇÕES IMPORTANTES</h2>
        <div class="separator"></div>
        <div class="form-group">
            <textarea id="outrosInputobj" name="observacao" class="outros-input text-input" rows="15" placeholder="Informe as observações"></textarea>
          </div>

        </div>

        <h2>RESPONSÁVEL PELO PREENCHIMENTO</h2>
            <div class="separator"></div>

            <div class="form-group">
                <label for="pa">FICHA</label>
                <input type="text" id="ficha" name="nome" required>
              </div>
              <div class="form-group">
                <label for="pulso">FIBRA</label>
                <input type="text" id="fibra" name="fibra" required>
              </div>
        

    </div>

  </div>

  </div>
  </div>






  </div>


</div>
<footer>
    <input type="submit" class="enviar_cadastro" name="enviar" value="enviar">
</footer>
</form>
<script>
    const outrosCheckboxobj = document.getElementById('outrosCheckboxobj');
    const outrosInputobj = document.getElementById('outrosInputobj');

    outrosCheckboxobj.addEventListener('change', function() {
        outrosInputobj.disabled = !this.checked;
    });
</script>
<script src="funcao.js" ></script>
<script src="esconder.js" ></script>
<script src="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag@2.0.1/dist/js/multi-select-tag.js"></script>
<script>
    new MultiSelectTag('prt_corpo')  // id
</script>

</body>
</html>
