<?php
    include("conecta.php");



    if(isset($_GET['id_paciente'])){
        $id=($_GET['id_paciente']);

        try {
            $sql = $pdo->prepare("SELECT * FROM paciente WHERE id_paciente=:id_paciente");
            $sql->bindValue("id_paciente", $id);
            $sql->execute();
            $resultado = $sql->fetch(PDO::FETCH_ASSOC);
            print_r($resultado);

            if($sql->rowCount()>0) {
                $nome = $resultado["nome"];
                $cpf = $resultado['cpf'];
                $idade = $resultado['idade'];
                $telefone = $resultado['telefone'];
                $genero = $resultado['sexo'];
                $nome_acompanhante = $resultado['nome_acompanhante'];
                $idade_acompanhante = $resultado['idade_acompanhante'];
            }
        } catch (PDOException $erro) {
            echo "houve erro, usuario não cadastrado";
        }


    }


    // Para voltar no formulário:
?>