<?php

include('conecta.php');

$problema = $_GET['problema'];

$query = $pdo->PREPARE("SELECT id, nome
     FROM subprob 
     WHERE idprob=:idprob
     ORDER BY nome ASC");

     $data = ['idprob' => $problema];

     $query->execute($data);
    $registros = $query->fetchAll(PDO::FETCH_ASSOC);

    echo '<option value="">Selecione um subproblema</option>';

    foreach($registros as $option) {
      ?>
        <option value="<?php echo $option['id']?>"><?php echo $option['nome']?></option>
        <?php
    }