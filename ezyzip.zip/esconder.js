function hideshow(val) {

    if(val==1) {
        document.querySelector('.ava1').style.display='block';
        document.querySelector('.ava2').style.display='none';
    }
    if(val==2) {
        document.querySelector('.ava1').style.display='none';
        document.querySelector('.ava2').style.display='block';

        document.querySelector('.ava1').style.display='none';
        document.querySelector('.ava2').style.display='block';

        document.querySelector('.ava1').style.display='none';
        document.querySelector('.ava2').style.display='block';
    }

}


function hideshowcorpo(val) {

    if(val==1) {
        document.querySelector('.corpo1').style.display='flex';
        document.querySelector('.corpo2').style.display='none';
    }
    if(val==2) {
        document.querySelector('.corpo1').style.display='none';
        document.querySelector('.corpo2').style.display='flex';
    }

}