<?php

include('conecta.php');

$sinais = $_GET['sinais'];

$query = $pdo->PREPARE("SELECT id, nome
     FROM subsinais
     WHERE idsinais=:idsinais
     ORDER BY nome ASC");

     $data = ['idsinais' => $sinais];

     $query->execute($data);
    $registros = $query->fetchAll(PDO::FETCH_ASSOC);

    echo '<option value="">Selecione um subsinal</option>';

    foreach($registros as $option) {
      ?>
        <option value="<?php echo $option['id']?>"><?php echo $option['nome']?></option>
        <?php
    }